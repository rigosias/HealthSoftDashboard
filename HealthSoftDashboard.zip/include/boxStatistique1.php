<div class="col-md-8">
                            <div class="card card-topline-aqua">
                                <div class="card-head">
                                    <header>HOSPITAL SURVEY</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
										<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
										<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body no-padding height-9">
									<div class="row">
									        <canvas id="chartjs_line"></canvas>
									</div>
								</div>
                            </div>
                       
                        </div>
                         <div class="col-md-4">
                            <div class="card card-topline-aqua">
                                <div class="card-head">
                                    <header>HOSPITAL SURVEY</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
										<a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
										<a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body no-padding height-9">
									<div class="row">
									        <canvas id="chartjs_polar"></canvas>
									</div>
								</div>
                            </div>
                        </div>