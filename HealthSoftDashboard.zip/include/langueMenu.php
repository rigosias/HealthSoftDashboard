 <script type="text/javascript">

               var lang =  "<?php echo substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2); ?>";

              function googleTranslateElementInit() {
                new google.translate.TranslateElement({pageLanguage: lang, includedLanguages: 'ar,de,en,es,fr,ch,pt,ja,ru', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
              }
        </script> 

        <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
<li class="dropdown dropdown-user">
<li class="dropdown language-switch">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="img/flags/gb.png" class="position-left" alt=""> Languages <span class="fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu">                                
                                <li>
                                    <div  id="google_translate_element" > </div>
                                </li>
                            </ul>
                        </li>