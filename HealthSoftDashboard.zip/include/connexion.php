<?php
try {
	$pdo=new PDO('mysql:host=localhost;dbname=genius; charset=utf8','root','');
	  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}

	  catch (PDOException $e) // On attrape les exceptions PDOException.


{

  echo 'La connexion a échoué.<br />';

  echo 'Informations : [', $e->getCode(), '] ', $e->getMessage(); // On affiche le n° de l'erreur ainsi que le message.

}
?>