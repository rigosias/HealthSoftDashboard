<div class="row">
							<div class="state-overview">
							<div class="col-lg-3 col-sm-6">
								<div class="overview-panel blue">
									<div class="symbol">
										<i class="fa fa-users usr-clr"></i>
									</div>
									<div class="value white">
										<p class="sbold addr-font-h1" data-counter="counterup" data-value="23">0</p>
										<p>APPOINTMENTS</p>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-sm-6">
								<div class="overview-panel green-bgcolor">
									<div class="symbol">
										<i class="fa fa-user"></i>
									</div>
									<div class="value white">
										<p class="sbold addr-font-h1" data-counter="counterup" data-value="48">0</p>
										<p>NEW PATIENTS</p>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-sm-6">
								<div class="overview-panel grey">
									<div class="symbol">
										<i class="fa fa-heartbeat"></i>
									</div>
									<div class="value white">
										<p class="sbold addr-font-h1" data-counter="counterup" data-value="14">0</p>
										<p>TODAY'S OPT</p>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-sm-6">
								<div class="overview-panel orange">
									<div class="symbol">
										<i class="fa fa-money"></i>
									</div>
									<div class="value white">
										<p class="sbold addr-font-h1" data-counter="counterup" data-value="3421">0</p><span>$</span>
										<p>Hospital Earning</p>
									</div>
								</div>
							</div>
						</div>
						</div>