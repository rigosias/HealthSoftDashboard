<?php
include('include/connexion.php') ;
 include('controllers/Patient.php');
 include('managers/PatientManager.php');


//function chargerClasse($classname)

//{

  // require 'managers/'.$classname.'.php';

//require 'controllers/'.$classname.'.php';


//}

// spl_autoload_register('chargerClasse');


      
   
 

//$tabForm[];

$tabForm = array (
	    'nomPatient'=>'$_POST[NomPatient]');
		/*'prenomPatient'=>$_POST[''],
		'codeNationalPatient'=>$_POST[''],
		'codeAttribueParLeSite'=>$_POST[''],
		'datePatient'=>$_POST[''],
		'sexePatient'=>$_POST[''],
		'communePatient'=>$_POST[''],
		'telephonePatient'=>$_POST[''],
		'lieuNaissancePatient'=>$_POST[],
		'localitePatient'=>$_POST[],
		'agePatient'=>$_POST[],
		'professionPatient'=>$_POST[],
		'prenomMerePatient'=>$_POST[],
		'statutMaritalPatient'=>$_POST[],
		'nomPrenomUrgence'=>$_POST[],
		'adresseUrgence'=>$_POST[],
		'foneUrgence'=>$_POST[],
		'nomResp1'=>$_POST[],
		'lienResp1'=>$_POST[],
		'adresseResp1'=>$_POST[],
		'foneResp1'=>$_POST[],
		'nomResp2'=>$_POST[''], 
		'lienResp2'=>$_POST[], 
		'adresseResp2'=>$_POST[''], 
		'foneResp2'=>$_POST[],
		'nomPrenomAutEnfant'=>$_POST[], 
		'lienParenteEnfant'=>$_POST[],
		'adresseAutEnfant'=>$_POST[],
		'telephoneAutEnfant'=>$_POST[]
	);*/

$manager=new PatientManager($pdo);
$patient = new Patient([
        'nomPatient'=>'jean',
		'prenomPatient'=>'Robert',
		'codeNationalPatient'=>'123',
		'codeAttribueParLeSite'=>'1234',
		'datePatient'=>'10/02/2005',
		'sexePatient'=>'F',
		'communePatient'=>'xxxx',
		'telephonePatient'=>'345678',
		'lieuNaissancePatient'=>'potoprens',
		'localitePatient'=>'granbois',
		'agePatient'=>'18',
		'professionPatient'=>'ingenieur',
		'prenomMerePatient'=>'Carmelle',
		'statutMaritalPatient'=>'plasaj',
		'nomPrenomUrgence'=>'jeaques',
		'adresseUrgence'=>'shada',
		'foneUrgence'=>'1233',
		'nomResp1'=>'thomas',
		'lienResp1'=>'tot',
		'adresseResp1'=>'marin',
		'foneResp1'=>'123',
		'nomResp2'=>'thomas2', 
		'lienResp2'=>'oncle', 
		'adresseResp2'=>'santo', 
		'foneResp2'=>'1234',
		'nomPrenomAutEnfant'=>'naelle', 
		'lienParenteEnfant'=>'oncle',
		'adresseAutEnfant'=>'santo',
		'telephoneAutEnfant'=>'ass'
]);$manager->add($patient);
//echo $patient->prenomPatient();
$patients=$manager->Affich();
//print_r($patients);
//foreach ($patients as $key => $value) {
	//echo "{$key} => {$value} ";
	

	//echo $patients->nomPatient();
    //print_r($patients);

    foreach ($patients as $unpatient) {
    	echo $unpatient->nomPatient() , htmlspecialchars($unpatient->prenomPatient()), $unpatient->agePatient(), '<br />';
    }
	
	
	
// Puis on fait une boucle pour tout afficher :

                                                                 

//}
	//echo $patient2->nomPatient();


 
?>