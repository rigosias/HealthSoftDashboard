<?php
	$str = "uquam";
	echo md5($str)."  /  ";
	echo password_hash($str, PASSWORD_DEFAULT);
?>