$().ready (function(){
	$("FormPrinsip").validate(
	{
      rules : {
      username:{
      required:true

      },

      password: {
      required:true
      
    },	
    messages : {
    username: "Veuillez fournir un prénom",
     password: "Veuillez fournir un nom d'au moins trois lettres",
    
  }



      }

	});


	});