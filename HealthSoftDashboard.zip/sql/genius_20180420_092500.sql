-- Valentina Studio --
-- MySQL dump --
-- ---------------------------------------------------------


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
-- ---------------------------------------------------------

drop database genius;
create database genius;
use genius;

-- CREATE TABLE "chambre" ----------------------------------
-- CREATE TABLE "chambre" --------------------------------------
CREATE TABLE `chambre` ( 
	`id_chambre` Int( 255 ) NOT NULL,
	`etage` Int( 255 ) NOT NULL,
	`capacite` Int( 255 ) NOT NULL,
	`prix` Double( 22, 0 ) NOT NULL,
	PRIMARY KEY ( `id_chambre` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "chirurgie" --------------------------------
-- CREATE TABLE "chirurgie" ------------------------------------
CREATE TABLE `chirurgie` ( 
	`id_chirurgie` Int( 255 ) NOT NULL,
	`chirurgien` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`anesthesiste` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	PRIMARY KEY ( `id_chirurgie` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------

CREATE TABLE `doctor` (

	id Int AUTO_INCREMENT PRIMARY KEY,
	nom_premon VarChar(100),
	dat_nais Date,
	sexe VarChar(10),
	specialite VarChar(100),
	phone VarChar(100),
	email  VarChar(100),
	address VarChar(100),
	photo VarChar(100),

	username VarChar(100),
	password VarChar(200),

	reseau_sociaux Text


);

-- CREATE TABLE "consultation_adulte" ----------------------
-- CREATE TABLE "consultation_adulte" --------------------------
CREATE TABLE `consultation_adulte` ( 
	`id_consultation` Int( 255 ) AUTO_INCREMENT,
	`date_consultation` Date NULL,
	`code_national` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`code_attrib` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`nom` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`prenom` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`age` Int( 255 ) NOT NULL,
	`sexe` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`group_sanguin` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`analyse` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`depistage_ca_col` Date NOT NULL,
	`depistage_ca_prostate` Date NOT NULL,
	`asthme_fam` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`cancer_fam` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`cardiopathie_fam` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`diabete_fam` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`epilepsie_fam` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`HTA_fam` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`turbeculose_fam` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`autres_1` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`accident_cere_vasc` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`allergies` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`asthme_pers` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`cancer_pers` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`cardiopathi` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`chirurgie_trauma` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`diabete_pers` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`epilepsie_pers` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`grossesse` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`hemoglobinopathie` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`hta_pers` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`hypercholesteromie` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`ist` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`malnutrition` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`malarie_moins_1_mois` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`malaria_plus_1_mois` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`tuberculose_pers` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`trouble_psychyatriques` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`alcool` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`drogue` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`tabac` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`autres_2` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`medicaments_actuels` Text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`remarque` Text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`poids` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`ta` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`taille` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`temp` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`pouls` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`fr` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`imc` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	PRIMARY KEY ( `id_consultation` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "consultation_enfant" ----------------------
-- CREATE TABLE "consultation_enfant" --------------------------
CREATE TABLE `consultation_enfant` ( 
	`code_natinal` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`code_attrib` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`age` Int( 50 ) NOT NULL,
	`sexe` VarChar( 50) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`refere` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`groupe_sangain` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`scolarite` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`electrophorese` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`poids_naissance` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`asthme_fam` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`cancer_fam` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`cardiopathie_fam` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`diabete_fam` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`epilepsie_fam` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`hta_fam` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`turberculose_fam` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`autres_1` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`allergies_pers` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`asthme_pers` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`cardiopathie_pers` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`chirurgie_trauma` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`diabete_pers` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`diphterie_pers` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`epilepsie_pers` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`hemoglobinopathie` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`hta_pers` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`ist_pers` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`malaria_moins_1_mois` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`malaria_plus_1_mois` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`malf_congenitales` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`malnutrition_perte_poids` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`premature` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`raa` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`rougeole` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`tuberculose_pers` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`varicelle` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`autres_2` Text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`medicaments_actuels` Text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`hospitalisation_anterieure` Text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`allaitement_mat_exclusif` Text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`preparation_nourrissons` Text CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`alimentation_mixte` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`diversification_alimentaire` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_bcg` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_polio` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_dtper` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_rougeole` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_rr` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_dt` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_hepatite_b` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_act_hib` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`vaccin_autre` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`date_ajout` Date NOT NULL,
	`nom` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`prenom` VarChar( 50 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL )
CHARACTER SET = latin1
COLLATE = latin1_swedish_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "employer" ---------------------------------
-- CREATE TABLE "employer" -------------------------------------
CREATE TABLE `employer` ( 
	`Id` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`nom` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`prenom` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`cin` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`nif` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`dat_nais` Date NOT NULL,
	`sexe` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`specialite` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`tel` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`adres` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`photo` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`date_enr` Date NOT NULL,
	PRIMARY KEY ( `Id` ) )
CHARACTER SET = latin1
COLLATE = latin1_swedish_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "examens_biologiques" ----------------------
-- CREATE TABLE "examens_biologiques" --------------------------
CREATE TABLE `examens_biologiques` ( 
	`id_examen` Int( 255 ) NOT NULL,
	`designation` Int( 255 ) NOT NULL,
	`resultat_examen` Int( 255 ) NOT NULL,
	PRIMARY KEY ( `id_examen` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "exames_radilogiques" ----------------------
-- CREATE TABLE "exames_radilogiques" --------------------------
CREATE TABLE `exames_radilogiques` ( 
	`id_examen` Int( 255 ) NOT NULL,
	`designation` Int( 255 ) NOT NULL,
	`resultat_examen` Int( 255 ) NOT NULL,
	`image` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	PRIMARY KEY ( `id_examen` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "facture" ----------------------------------
-- CREATE TABLE "facture" --------------------------------------
CREATE TABLE `facture` ( 
	`id_facture` Int( 255 ) NOT NULL,
	`date_facture` Date NOT NULL,
	`total` Double( 22, 0 ) NOT NULL,
	PRIMARY KEY ( `id_facture` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "hopital" ----------------------------------
-- CREATE TABLE "hopital" --------------------------------------
CREATE TABLE `hopital` ( 
	`idhopital` Int( 255 ) NOT NULL,
	`adress` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`nomofficiel` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`phone` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`email` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`fax` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`boite_postal` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`dateAj` Date NOT NULL,
	`scpecialite` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`reponsable` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	PRIMARY KEY ( `idhopital` ) )
CHARACTER SET = latin1
COLLATE = latin1_swedish_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "hopital_du_jour" --------------------------
-- CREATE TABLE "hopital_du_jour" ------------------------------
CREATE TABLE `hopital_du_jour` ( 
	`id_hdj` Int( 255 ) NOT NULL )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "hospitalisation" --------------------------
-- CREATE TABLE "hospitalisation" ------------------------------
CREATE TABLE `hospitalisation` ( 
	`id_admission` Int( 255 ) AUTO_INCREMENT NOT NULL,
	`date_admission` Date NOT NULL,
	`type_admission` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`motif_admission` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`medecin_traitant` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`nom_accompagnant` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`prenom_accompagnant` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`lien_parente` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`date_entreeAcc` Date NOT NULL,
	`date_sortieAcc` Date NOT NULL,
	`date_sortie` Date NOT NULL,
	`motif_sortie` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`resultat_sortie` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`date_deces` Date NOT NULL,
	`motif_deces` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	PRIMARY KEY ( `id_admission` ),
	CONSTRAINT `unique_id_admission` UNIQUE( `id_admission` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 1;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "medecin" ----------------------------------
-- CREATE TABLE "medecin" --------------------------------------
CREATE TABLE `medecin` ( 
	`id_medcin` Int( 255 ) AUTO_INCREMENT NOT NULL,
	`nom_medcin` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`prenom_medcin` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`specialiteMedcin` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`adressMedcin` Int( 11 ) NULL,
	`imageMecin` VarChar( 50 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`sexeMedcin` VarChar( 25 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Inconnu',
	`tel_medcin` Int( 255 ) NOT NULL,
	`email` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	PRIMARY KEY ( `id_medcin` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 1;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "patient" ----------------------------------
-- CREATE TABLE "patient" --------------------------------------
CREATE TABLE `patient` ( 
	`idPatient` Int( 255 ) AUTO_INCREMENT NOT NULL,
	`nomPatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`prenomPatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`codeNationalPatient`  VarChar( 255 ) NOT NULL,
	`codeAttribueParLeSite` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`sexePatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`communePatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`telephonePatient` VarChar( 255 ) NULL,
	`lieuNaissancePatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`localitePatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`agePatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`professionPatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`prenomMerePatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`statutMaritalPatient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`nomPrenomUrgence` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`adresseUrgence` VarChar( 125 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`foneUrgence` VarChar( 255 ) NULL,
	`nomResp1` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`lienResp1` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 'non defini',
	`adresseResp1` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`foneResp1` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`nomResp2` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`lienResp2` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`adresseResp2` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`foneResp2` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`nomPrenomAutEnfant` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`lienParenteEnfant` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`adresseAutEnfant` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`telephoneAutEnfant` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`idhopital` VarChar( 255 ) NOT NULL,
	`userid` VarChar( 255 ) NOT NULL,
	PRIMARY KEY ( `idPatient` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 98;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "permissions" ------------------------------
-- CREATE TABLE "permissions" ----------------------------------
CREATE TABLE `permissions` ( 
	`id_perm` Int( 255 ) AUTO_INCREMENT NOT NULL,
	`nom` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`description` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`status` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`date` Date NOT NULL,
	PRIMARY KEY ( `id_perm` ) )
CHARACTER SET = latin1
COLLATE = latin1_swedish_ci
ENGINE = InnoDB
AUTO_INCREMENT = 2;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "prescription" -----------------------------
-- CREATE TABLE "prescription" ---------------------------------
CREATE TABLE `prescription` ( 
	`id_prescription` Int( 255 ) NOT NULL,
	`dare_prescription` Date NULL,
	`nom_patient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`prenom_patient` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`note` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	PRIMARY KEY ( `id_prescription` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "provenance" -------------------------------
-- CREATE TABLE "provenance" -----------------------------------
CREATE TABLE `provenance` ( 
	`id_provenance` Int( 255 ) NOT NULL,
	`province` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	PRIMARY KEY ( `id_provenance` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "rendez_vous" ------------------------------
-- CREATE TABLE "rendez_vous" ----------------------------------
CREATE TABLE `rendez_vous` ( 
	`coderdv` Int( 255 ) AUTO_INCREMENT NOT NULL,
	`medecin` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	`date_rdv` Date NULL,
	`sevice` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	PRIMARY KEY ( `coderdv` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB
AUTO_INCREMENT = 1;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "service" ----------------------------------
-- CREATE TABLE "service" --------------------------------------
CREATE TABLE `service` ( 
	`id_service` Int( 255 ) NOT NULL,
	`nom_service` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
	PRIMARY KEY ( `id_service` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "specialite" -------------------------------
-- CREATE TABLE "specialite" -----------------------------------
CREATE TABLE `specialite` ( 
	`id_specialite` Int( 255 ) NOT NULL,
	`specialite` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	PRIMARY KEY ( `id_specialite` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "tritement" --------------------------------
-- CREATE TABLE "tritement" ------------------------------------
CREATE TABLE `tritement` ( 
	`id_traitement` Int( 255 ) NOT NULL,
	`date_traitement` Date NULL,
	`prix_traitement` Double( 22, 0 ) NULL,
	PRIMARY KEY ( `id_traitement` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "type_consultation" ------------------------
-- CREATE TABLE "type_consultation" ----------------------------
CREATE TABLE `type_consultation` ( 
	`id_type_consultation` Int( 255 ) NOT NULL,
	`type_consultaiton` VarChar( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NULL,
	`prix_consultation` Double( 22, 0 ) NULL,
	PRIMARY KEY ( `id_type_consultation` ) )
CHARACTER SET = utf8
COLLATE = utf8_general_ci
ENGINE = InnoDB;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "users" ------------------------------------
-- CREATE TABLE "users" ----------------------------------------
CREATE TABLE `users` ( 
	`userid` Int( 255 ) AUTO_INCREMENT NOT NULL,
	`nom` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`prenom` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`cin` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`adresse` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`tel` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`username` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`password` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`status` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`date` Date NOT NULL,
	`id_perm` Int( 255 ) NOT NULL,
	PRIMARY KEY ( `userid` ) )
CHARACTER SET = latin1
COLLATE = latin1_swedish_ci
ENGINE = InnoDB
AUTO_INCREMENT = 2;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE TABLE "login_history" ----------------------------
-- CREATE TABLE "login_history" --------------------------------
CREATE TABLE `login_history` ( 
	`id` Int( 255 ) AUTO_INCREMENT NOT NULL,
	`username` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
	`userid` Int( 255 ) NOT NULL,
	`date_in` DateTime NOT NULL,
	`date_out` DateTime NOT NULL,
	PRIMARY KEY ( `id` ) )
CHARACTER SET = latin1
COLLATE = latin1_swedish_ci
ENGINE = InnoDB
AUTO_INCREMENT = 1;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- Dump data of "chambre" ----------------------------------
-- ---------------------------------------------------------


-- Dump data of "chirurgie" --------------------------------
-- ---------------------------------------------------------


-- Dump data of "consultation_adulte" ----------------------
-- ---------------------------------------------------------


-- Dump data of "consultation_enfant" ----------------------
-- ---------------------------------------------------------


-- Dump data of "employer" ---------------------------------
-- ---------------------------------------------------------


-- Dump data of "examens_biologiques" ----------------------
-- ---------------------------------------------------------


-- Dump data of "exames_radilogiques" ----------------------
-- ---------------------------------------------------------


-- Dump data of "facture" ----------------------------------
-- ---------------------------------------------------------


-- Dump data of "hopital" ----------------------------------
-- ---------------------------------------------------------


-- Dump data of "hopital_du_jour" --------------------------
-- ---------------------------------------------------------


-- Dump data of "hospitalisation" --------------------------
-- ---------------------------------------------------------


-- Dump data of "medecin" ----------------------------------
-- ---------------------------------------------------------


-- Dump data of "patient" ----------------------------------
INSERT INTO `patient`(`idPatient`,`nomPatient`,`prenomPatient`,`codeNationalPatient`,`codeAttribueParLeSite`,`sexePatient`,`communePatient`,`telephonePatient`,`lieuNaissancePatient`,`localitePatient`,`agePatient`,`professionPatient`,`prenomMerePatient`,`statutMaritalPatient`,`nomPrenomUrgence`,`adresseUrgence`,`foneUrgence`,`nomResp1`,`lienResp1`,`adresseResp1`,`foneResp1`,`nomResp2`,`lienResp2`,`adresseResp2`,`foneResp2`,`nomPrenomAutEnfant`,`lienParenteEnfant`,`adresseAutEnfant`,`telephoneAutEnfant`,`idhopital`,`userid`) VALUES ( '1', 'Bérthelo', 'Peterson', '123', '1234', 'F', 'xxxx', '345678', 'potoprens', 'granbois', '18', 'ingenieur', 'Carmelle', 'plasaj', 'jeaques', '0', '1233', 'thomas', 'tot', 'marin', '123', 'thomas2', 'oncle', 'santo', '1234', 'naelle', 'oncle', 'santo', 'ass', '0', '0' );
INSERT INTO `patient`(`idPatient`,`nomPatient`,`prenomPatient`,`codeNationalPatient`,`codeAttribueParLeSite`,`sexePatient`,`communePatient`,`telephonePatient`,`lieuNaissancePatient`,`localitePatient`,`agePatient`,`professionPatient`,`prenomMerePatient`,`statutMaritalPatient`,`nomPrenomUrgence`,`adresseUrgence`,`foneUrgence`,`nomResp1`,`lienResp1`,`adresseResp1`,`foneResp1`,`nomResp2`,`lienResp2`,`adresseResp2`,`foneResp2`,`nomPrenomAutEnfant`,`lienParenteEnfant`,`adresseAutEnfant`,`telephoneAutEnfant`,`idhopital`,`userid`) VALUES ( '2', 'Inge Ké kontan', 'Guirlande', '123', '1234', 'F', 'xxxx', '345678', 'potoprens', 'granbois', '18', 'ingenieur', 'Carmelle', 'plasaj', 'jeaques', '0', '1233', 'thomas', 'tot', 'marin', '123', 'thomas2', 'oncle', 'santo', '1234', 'naelle', 'oncle', 'santo', 'ass', '0', '0' );
-- ---------------------------------------------------------


-- Dump data of "permissions" ------------------------------
INSERT INTO `permissions`(`id_perm`,`nom`,`description`,`status`,`date`) VALUES ( '1', 'SUPERADMIN', 'cet utlisateur peut tout faire', 'activated', '2018-03-07' );

INSERT INTO `permissions`(`id_perm`,`nom`,`description`,`status`,`date`) VALUES ( '2', 'HOPITAL PV', 'cet utlisateur peut tout faire', 'activated', '2018-03-07' );

INSERT INTO `permissions`(`id_perm`,`nom`,`description`,`status`,`date`) VALUES ( '3', 'HOPITAL DELMAS', 'cet utlisateur peut tout faire', 'activated', '2018-06-07' );

-- ---------------------------------------------------------


-- Dump data of "prescription" -----------------------------
-- ---------------------------------------------------------


-- Dump data of "provenance" -------------------------------
-- ---------------------------------------------------------


-- Dump data of "rendez_vous" ------------------------------
-- ---------------------------------------------------------


-- Dump data of "service" ----------------------------------
-- ---------------------------------------------------------


-- Dump data of "specialite" -------------------------------
-- ---------------------------------------------------------


-- Dump data of "traitement" --------------------------------
-- ---------------------------------------------------------


-- Dump data of "type_consultation" ------------------------
-- ---------------------------------------------------------


-- Dump data of "users" ------------------------------------
INSERT INTO `users`(`userid`,`nom`,`prenom`,`cin`,`adresse`,`tel`,`username`,`password`,`status`,`date`,`id_perm`) VALUES ( '1', 'Rigobert', 'Osias', '863848643', 'tabarre', '928746842', 'rosias', '$2y$10$fc9WH9YSoTnstV1yS0Ea7eTwHKVybzFR/TfBByKV8W1sM9VC/fXSe', 'activated', '2020-03-07', '1' );

INSERT INTO `users`(`userid`,`nom`,`prenom`,`cin`,`adresse`,`tel`,`username`,`password`,`status`,`date`,`id_perm`) VALUES ( '2', 'Bertelot', 'Peterson', '863848643', 'tabarre', '928746842', 'hop1', '$2y$10$fc9WH9YSoTnstV1yS0Ea7eTwHKVybzFR/TfBByKV8W1sM9VC/fXSe', 'activated', now(), '2' );

INSERT INTO `users`(`userid`,`nom`,`prenom`,`cin`,`adresse`,`tel`,`username`,`password`,`status`,`date`,`id_perm`) VALUES ( '3', 'Celicourt', 'Shilove', '863848643', 'tabarre', '928746842', 'hop2', '$2y$10$fc9WH9YSoTnstV1yS0Ea7eTwHKVybzFR/TfBByKV8W1sM9VC/fXSe', 'activated', now(), '3' );
-- ---------------------------------------------------------


-- Dump data of "login_history" ----------------------------
-- ---------------------------------------------------------


-- CREATE INDEX "fk_ho" ------------------------------------
-- CREATE INDEX "fk_ho" ----------------------------------------
CREATE INDEX `fk_ho` USING BTREE ON `patient`( `idhopital` );
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE INDEX "fk_user" ----------------------------------
-- CREATE INDEX "fk_user" --------------------------------------
CREATE INDEX `fk_user` USING BTREE ON `patient`( `userid` );
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE INDEX "lnk_permissions_users" --------------------
-- CREATE INDEX "lnk_permissions_users" ------------------------
CREATE INDEX `lnk_permissions_users` USING BTREE ON `users`( `id_perm` );
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE LINK "lnk_patient_hopital" -----------------------
-- CREATE LINK "lnk_patient_hopital" ---------------------------
ALTER TABLE `hopital`
	ADD CONSTRAINT `lnk_patient_hopital` FOREIGN KEY ( `idhopital` )
	REFERENCES `patient`( `idPatient` )
	ON DELETE Cascade
	ON UPDATE Cascade;
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE LINK "fk_ho" -------------------------------------
-- CREATE LINK "fk_ho" -----------------------------------------
/* ALTER TABLE `patient`
	ADD CONSTRAINT `fk_ho` FOREIGN KEY ( `idhopital` )
	REFERENCES `hopital`( `idhopital` )
	ON DELETE Restrict
	ON UPDATE Restrict;*/
-- -------------------------------------------------------------
-- ---------------------------------------------------------


-- CREATE LINK "fk_user" -----------------------------------
-- CREATE LINK "fk_user" ---------------------------------------
/*ALTER TABLE `patient`
	ADD CONSTRAINT `fk_user` FOREIGN KEY ( `userid` )
	REFERENCES `users`( `userid` )
	ON DELETE Restrict
	ON UPDATE Restrict;*/
-- -------------------------------------------------------------
-- ---------------------------------------------------------


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
-- ---------------------------------------------------------
