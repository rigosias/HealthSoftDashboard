<?php
	
	include ('../include/connexion.php');

	$nom_premon = $_POST['nom_premon'];
	$dat_nais = $_POST['dat_nais'];
	$sexe = $_POST['sexe'];
	$specialite = $_POST['specialite'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	$photo = "...";

	$username = $_POST['username'];
	$password = $_POST['password'];

	$reseau_sociaux = $_POST['reseau_sociaux'] ."/". $_POST['reseau_sociaux_2'] ."/". $_POST['reseau_sociaux_3'] ."/". $_POST['reseau_sociaux_4'] ."/". $_POST['reseau_sociaux_5'];
  

    $q=$pdo->prepare("INSERT INTO doctor(
								    nom_premon, 
									dat_nais,
									sexe,
									specialite, 
									phone,
									email,
									address,
									photo,
									username, 
									password ,
									reseau_sociaux)

									VALUES
									(
									    '$nom_premon', 
										'$dat_nais',
										'$sexe',
										'$specialite', 
										'$phone',
										'$email',
										'$address',
										'$photo',
										'$username', 
										'$password',
										'$reseau_sociaux'
									);");



							try{

							    $info =	$q->execute();

							    if($info == true){
		    						echo "<script> alert('succes');  window.location.href='../view/add_doctor.php'; </script>";
		    					}
		    					else
		    						echo "<script> alert('echec'); window.history.back(); </script>";

							} catch (Exception $e) {
							    echo "<script> alert('erreur verifier les information'); window.history.back(); </script>";
							}





?>