<?php
			include ('../include/connexion.php');
			include('../Controller/consultation/ConsultationEnfant.php');
			include('ConsultationEnfantManager.php');

	
            $code_natinal = $_POST['code_national'];
            $code_attrib = $_POST['code_attrib'];
            $nom = $_POST['nom'];
            $prenom	= $_POST['prenom'];
            $age = $_POST['age'];
            $sexe = $_POST['sexe'];
            $refere	 = $_POST['refere'];
            $groupe_sanguin      = $_POST['groupe_sanguin'];
            $scolarite = $_POST['scolarise'];
            $electrophorese = $_POST['electrophorese'];
            $poids_naissance = $_POST['poids_naissance'];
            $asthme_fam = $_POST['asthme_fam'];
            $cancer_fam = $_POST['cancer_fam'];
            $cardiopathie_fam = $_POST['cardiopathie_fam'];
            $diabete_fam = $_POST['diabete_fam'];
            $epilepsie_fam = $_POST['epilepsie_fam'];
            $hta_fam = $_POST['hta_fam'];
            $turberculose_fam = $_POST['turberculose_fam'];
            $autres_1 = $_POST['autres_1'];
            $allergies_pers = $_POST['allergies_pers'];
            $asthme_pers = $_POST['asthme_pers'];
            $cardiopathie_pers = $_POST['cardiopathie_pers'];
            $chirurgie_trauma = $_POST['chirurgie_trauma'];
            $diabete_pers = $_POST['diabete_pers'];
            $diphterie_pers = $_POST['diphterie_pers'];
            $epilepsie_pers = $_POST['epilepsie_pers'];
            $hemoglobinopathie = $_POST['hemoglobinopathie'];
            $hta_pers = $_POST['hta_pers'];
            $ist_pers = $_POST['ist_pers'];
            $malaria_moins_1_mois = $_POST['malaria_moins_1_mois'];
            $malaria_plus_1_mois = $_POST['malaria_plus_1_mois'];
            $malf_congenitales = $_POST['malf_congenitales'];
            $malnutrition_perte_poids = $_POST['malnutrition_perte_poids'];
            $premature = $_POST['premature'];
            $raa = $_POST['raa'];
            $rougeole = $_POST['rougeole'];
            $tuberculose_pers = $_POST['turberculose_pers'];
            $varicelle = $_POST['varicelle'];
            $autres_2 = $_POST['autres_2'];
            $medicaments_actuels = $_POST['medicaments_actuels'];
            $hospitalisation_anterieure = $_POST['hospitalisation_anterieure'];
            $allaitement_mat_exclusif = $_POST['allaitement_mat_exclusif'];
            $preparation_nourrissons = $_POST['preparation_nourrissons'];
            $alimentation_mixte = $_POST['alimentation_mixte'];
            $diversification_alimentaire = $_POST['diversification_alimentaire'];
            $vaccin_bcg = $_POST['vaccin_bcg'];
            $vaccin_polio = $_POST['vaccin_polio'];
            $vaccin_dtper = $_POST['vaccin_dtper'];
            $vaccin_rougeole = $_POST['vaccin_rougeole'];
            $vaccin_rr = $_POST['vaccin_rr'];
            $vaccin_dt = $_POST['vaccin_dt'];
            $vaccin_hepatite_b = $_POST['vaccin_hepatite_b'];
            $vaccin_act_hib = $_POST['vaccin_act_hib'];
            $vaccin_autre = $_POST['vaccin_autre'];
            $date_consultation = date("y-m-d");


            $ConsultationEnfant = new ConsultationEnfant(

                  $code_natinal,
            	$code_attrib ,
	            $nom ,
	            $prenom	,
	            $age ,
                  $sexe,
	            $refere	 ,
                  $groupe_sanguin,
	            $scolarite ,
	            $electrophorese ,
	            $poids_naissance ,
	            $asthme_fam ,
	            $cancer_fam ,
	            $cardiopathie_fam ,
	            $diabete_fam ,
	            $epilepsie_fam ,
	            $hta_fam ,
	            $turberculose_fam ,
	            $autres_1 ,
	            $allergies_pers ,
	            $asthme_pers ,
	            $cardiopathie_pers ,
	            $chirurgie_trauma ,
	            $diabete_pers,
	            $diphterie_pers ,
	            $epilepsie_pers ,
	            $hemoglobinopathie ,
	            $hta_pers ,
	            $ist_pers ,
	            $malaria_moins_1_mois ,
	            $malaria_plus_1_mois ,
	            $malf_congenitales ,
	            $malnutrition_perte_poids ,
	            $premature ,
	            $raa ,
	            $rougeole ,
	            $tuberculose_pers ,
	            $varicelle ,
	            $autres_2,
	            $medicaments_actuels ,
	            $hospitalisation_anterieure ,
	            $allaitement_mat_exclusif ,
	            $preparation_nourrissons ,
	            $alimentation_mixte ,
	            $diversification_alimentaire ,
	            $vaccin_bcg  ,
	            $vaccin_polio ,
	            $vaccin_dtper ,
	            $vaccin_rougeole ,
	            $vaccin_rr ,
	            $vaccin_dt ,
	            $vaccin_hepatite_b ,
	            $vaccin_act_hib ,
	            $vaccin_autre ,
	            $date_consultation
            );

            $ConsultationEnfantManager = new ConsultationEnfantManager($pdo);

            $ConsultationEnfantManager->add($ConsultationEnfant)
	

?>