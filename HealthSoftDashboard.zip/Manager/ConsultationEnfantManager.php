<?php

class ConsultationEnfantManager{

	private $_pdo;
	
	public function __construct($pdo) {
		$this->setDb($pdo);		
	}
	
	
   public function add(ConsultationEnfant $ConsultationEnfant)
    {
    	

		$q=$this->_pdo->prepare("INSERT INTO consultation_enfant (
								code_natinal,
								code_attrib, 
								nom, 
								prenom,	
								age,
								sexe, 
								refere,	
								groupe_sangain, 
								scolarite, 
								electrophorese ,
								poids_naissance ,
								asthme_fam ,
								cancer_fam ,
								cardiopathie_fam ,
								diabete_fam ,
								epilepsie_fam ,
								hta_fam ,
								turberculose_fam ,
								autres_1 ,
								allergies_pers ,
								asthme_pers ,
								cardiopathie_pers ,
								chirurgie_trauma ,
								diabete_pers ,
								diphterie_pers ,
								epilepsie_pers, 
								hemoglobinopathie ,
								hta_pers ,
								ist_pers ,
								malaria_moins_1_mois ,
								malaria_plus_1_mois ,
								malf_congenitales ,
								malnutrition_perte_poids ,
								premature ,
								raa ,
								rougeole ,
								tuberculose_pers ,
								varicelle ,
								autres_2,
								medicaments_actuels ,
								hospitalisation_anterieure, 
								allaitement_mat_exclusif ,
								preparation_nourrissons,
								alimentation_mixte ,
								diversification_alimentaire, 
								vaccin_bcg ,
								vaccin_polio ,
								vaccin_dtper ,
								vaccin_rougeole, 
								vaccin_rr ,
								vaccin_dt ,
								vaccin_hepatite_b ,
								vaccin_act_hib ,
								vaccin_autre ,
								date_ajout)

								VALUES('".
								$ConsultationEnfant->getCode_natinal()."','".
								$ConsultationEnfant->getCode_attrib()."','". 
								$ConsultationEnfant->getNom()."','". 
								$ConsultationEnfant->getPrenom()."',".
								$ConsultationEnfant->getAge().",'".	
								$ConsultationEnfant->getSexe()."','". 
								$ConsultationEnfant->getRefere()."','".	
								$ConsultationEnfant->getGroupeSanguin()."','". 
								$ConsultationEnfant->getScolarite()."','". 
								$ConsultationEnfant->getElectrophorese()."','".
								$ConsultationEnfant->getPoids_naissance()."','".
								$ConsultationEnfant->getAsthme_fam()."','".
								$ConsultationEnfant->getCancer_fam()."','".
								$ConsultationEnfant->getCardiopathie_fam()."','".
								$ConsultationEnfant->getDiabete_fam()."','".
								$ConsultationEnfant->getEpilepsie_fam()."','".
								$ConsultationEnfant->getHta_fam()."','".
								$ConsultationEnfant->getTurberculose_fam()."','".
								$ConsultationEnfant->getAutres_1()."','".
								$ConsultationEnfant->getAllergies_pers()."','".
								$ConsultationEnfant->getAsthme_pers()."','".
								$ConsultationEnfant->getCardiopathie_pers()."','".
								$ConsultationEnfant->getChirurgie_trauma()."','".
								$ConsultationEnfant->getDiabete_pers()."','".
								$ConsultationEnfant->getDiphterie_pers()."','".
								$ConsultationEnfant->getEpilepsie_pers()."','". 
								$ConsultationEnfant->getHemoglobinopathie()."','".
								$ConsultationEnfant->getHta_pers()."','".
								$ConsultationEnfant->getIst_pers()."','".
								$ConsultationEnfant->getMalaria_moins_1_mois()."','".
								$ConsultationEnfant->getMalaria_plus_1_mois()."','".
								$ConsultationEnfant->getMalf_congenitales()."','".
								$ConsultationEnfant->getMalnutrition_perte_poids()."','".
								$ConsultationEnfant->getPremature()."','".
								$ConsultationEnfant->getRaa()."','".
								$ConsultationEnfant->getRougeole()."','".
								$ConsultationEnfant->getTuberculose_pers()."','".
								$ConsultationEnfant->getVaricelle()."','".
								$ConsultationEnfant->getAutres_2()."','".
								$ConsultationEnfant->getMedicaments_actuels()."','".
								$ConsultationEnfant->getHospitalisation_anterieure()."','". 
								$ConsultationEnfant->getAllaitement_mat_exclusif()."','".
								$ConsultationEnfant->getPreparation_nourrissons()."','".
								$ConsultationEnfant->getAlimentation_mixte()."','".
								$ConsultationEnfant->getDiversification_alimentaire()."','". 
								$ConsultationEnfant->getVaccin_bcg()."','".
								$ConsultationEnfant->getVaccin_polio()."','".
								$ConsultationEnfant->getVaccin_dtper()."','".
								$ConsultationEnfant->getVaccin_rougeole()."','". 
								$ConsultationEnfant->getVaccin_rr()."','".
								$ConsultationEnfant->getVaccin_dt()."','".
								$ConsultationEnfant->getVaccin_hepatite_b()."','".
								$ConsultationEnfant->getVaccin_act_hib()."','".
								$ConsultationEnfant->getVaccin_autre()."','".
								$ConsultationEnfant->getDate_consultation()
								."') ;");
		
	    					try {

							    $info =	$q->execute();

							    if($info == true){
		    						echo "<script> alert('succes'); </script>";
		    					}
		    					else
		    						echo "<script> alert('succes'); </script>";

							} catch (Exception $e) {
							    echo "<script> alert('erreur verifier les information'); </script>";
							}

	    					
		
	} 


	public function Affich(){
        $patients = [];

		
		$q=$this->_pdo->query('SELECT * FROM patient LIMIT 10');
	  
		while ($donnees = $q->fetch(PDO::FETCH_ASSOC))
      {
       
      $patients []=  new patient($donnees);

      }
     return $patients;
	 }
	 
	 
	 
	 public function AffichUnPatient($info){
        $patients = [];

		
		$q=$this->_pdo->query('SELECT *  FROM patient WHERE idPatient='.$info);
	  
		while ($donnees = $q->fetch(PDO::FETCH_ASSOC))
	      {
	       
	      $patients []=  new patient($donnees);

	      }
	     return $patients;
	 }

	public function count()

  {

    return $this->_db->query('SELECT COUNT(*) FROM patient')->fetchColumn();

  }	
	public function delete(Patient $patient)

  {

    $this->_db->getExec('DELETE FROM personnages WHERE id = '.$patient->id());

  }	
		
		
	
  public function update(Patient $patient)

  {

    $q = $this->_db->getPrepare('UPDATE patient SET  WHERE id = :id');

    

    $q->bindValue(':degats', $perso->getDegats()."','". PDO::PARAM_INT);

    $q->bindValue(':id', $perso->id()."','". PDO::PARAM_INT);

    

    $q->getExecute();

  }	
	
	
	
	
  public function setDb(PDO $pdo)

 {

   $this->_pdo = $pdo;

  }
}




?>