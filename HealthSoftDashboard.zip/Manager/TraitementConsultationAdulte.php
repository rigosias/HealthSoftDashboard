<?php

	include ('../include/connexion.php');
	
	// $id_consultation  = $_POST['id_consultation'] ;
	$date_consultation   = 'now()' ; 
	$code_national   = $_POST['code_national'] ; 
	$code_attrib   = $_POST['code_attrib'] ; 
	$nom   = $_POST['nom'] ; 
	$prenom   = $_POST['prenom'] ; 
	$age  = $_POST['age'] ;
	$sexe  = $_POST['sexe'] ;
	$group_sanguin  = $_POST['group_sanguin'] ;
	$analyse  = $_POST['analyse'] ;
	$depistage_ca_col  = $_POST['depistage_ca_col'] ;
	$depistage_ca_prostate  = $_POST['depistage_ca_prostate'] ;
	$asthme_fam   = $_POST['asthme_fam'] ; 
	$cancer_fam  = $_POST['cancer_fam'] ;
	$cardiopathie_fam  = $_POST['cardiopathie_fam'] ;
	$diabete_fam  = $_POST['diabete_fam'] ;
	$epilepsie_fam   = $_POST['epilepsie_fam'] ; 
	$HTA_fam  = $_POST['HTA_fam'] ;
	$turbeculose_fam  = $_POST['turbeculose_fam'] ;
	$autres_1  = $_POST['autres_1'] ;
	$accident_cere_vasc  = $_POST['accident_cere_vasc'] ; 
	$allergies  = $_POST['allergies'] ;
	$asthme_pers   = $_POST['asthme_pers'] ; 
	$cancer_pers  = $_POST['cancer_pers'] ;
	$cardiopathi  = $_POST['cardiopathie'] ;
	$chirurgie_trauma  = $_POST['chirurgie_trauma'] ;
	$diabete_pers  = $_POST['diabete_pers'] ;
	$epilepsie_pers  = $_POST['epilepsie_pers'] ;
	$grossesse  = $_POST['grossesse'] ;
	$hemoglobinopathie   = $_POST['hemoglobinopathie'] ; 
	$hta_pers  = $_POST['hta_pers'] ;
	$hypercholesteromie  = $_POST['hypercholesteromie'] ;
	$ist  = $_POST['ist'] ;
	$malnutrition  = $_POST['malnutrition'] ;
	$malarie_moins_1_mois  = $_POST['malarie_moins_1_mois'] ;
	$malaria_plus_1_mois  = $_POST['malaria_plus_1_mois'] ;
	$tuberculose_pers  = $_POST['turbeculose_fam'] ;
	$trouble_psychyatriques  = $_POST['trouble_psychyatriques'] ;
	$alcool   = $_POST['alcool'] ; 
	$drogue  = $_POST['drogue'] ;
	$tabac  = $_POST['tabac'] ;
	$autres_2  = $_POST['autres_2'] ;
	$medicaments_actuels  = $_POST['medicaments_actuels'] ;
	$remarque  = $_POST['autres_4'] ;
	$poids  = $_POST['poids'] ;
	$ta  = $_POST['ta'] ;
	$taille  = $_POST['taille'] ;
	$temp  = $_POST['temp'] ;
	$pouls  = $_POST['pouls'] ;
	$fr  = $_POST['fr'] ;
	$imc  = $_POST['imc'] ;


	//$_pdo = $pdo;

	//$_pdo->setDb($conect);	

	

	$q=$pdo->prepare("INSERT INTO consultation_adulte(
								
								date_consultation,  
								code_national,  
								code_attrib,  
								nom,  
								prenom,  
								age, 
								sexe, 
								group_sanguin ,
								analyse ,
								depistage_ca_col ,
								depistage_ca_prostate, 
								asthme_fam  ,
								cancer_fam ,
								cardiopathie_fam ,
								diabete_fam ,
								epilepsie_fam , 
								HTA_fam ,
								turbeculose_fam ,
								autres_1 ,
								accident_cere_vasc , 
								allergies ,
								asthme_pers , 
								cancer_pers ,
								cardiopathi ,
								chirurgie_trauma ,
								diabete_pers, 
								epilepsie_pers ,
								grossesse ,
								hemoglobinopathie , 
								hta_pers ,
								hypercholesteromie ,
								ist ,
								malnutrition ,
								malarie_moins_1_mois ,
								malaria_plus_1_mois, 
								tuberculose_pers, 
								trouble_psychyatriques, 
								alcool,  
								drogue, 
								tabac, 
								autres_2, 
								medicaments_actuels ,
								remarque, 
								poids ,
								ta, 
								taille, 
								temp, 
								pouls, 
								fr, 
								imc)

								VALUES(

							
								$date_consultation,  
								'$code_national',  
								'$code_attrib',  
								'$nom',  
								'$prenom',  
								$age, 
								'$sexe', 
								'$group_sanguin' ,
								'$analyse' ,
								'$depistage_ca_col' ,
								'$depistage_ca_prostate', 
								'$asthme_fam'  ,
								'$cancer_fam' ,
								'$cardiopathie_fam' ,
								'$diabete_fam' ,
								'$epilepsie_fam' , 
								'$HTA_fam' ,
								'$turbeculose_fam' ,
								'$autres_1' ,
								'$accident_cere_vasc' , 
								'$allergies' ,
								'$asthme_pers' , 
								'$cancer_pers' ,
								'$cardiopathi' ,
								'$chirurgie_trauma' ,
								'$diabete_pers', 
								'$epilepsie_pers' ,
								'$grossesse' ,
								'$hemoglobinopathie' , 
								'$hta_pers' ,
								'$hypercholesteromie' ,
								'$ist' ,
								'$malnutrition' ,
								'$malarie_moins_1_mois' ,
								'$malaria_plus_1_mois' , 
								'$tuberculose_pers' , 
								'$trouble_psychyatriques' , 
								'$alcool',  
								'$drogue', 
								'$tabac', 
								'$autres_2', 
								'$medicaments_actuels', 
								'$remarque', 
								'$poids', 
								'$ta', 
								'$taille', 
								'$temp', 
								'$pouls', 
								'$fr', 
								'$imc'

							  );");

							try{

							    $info =	$q->execute();

							    if($info == true){
		    						echo "<script> alert('succes'); </script>";
		    					}
		    					else
		    						echo "<script> alert('echec'); </script>";

							} catch (Exception $e) {
							    echo "<script> alert('erreur verifier les information'); </script>";
							}







?>