<?php 
session_start();
if ($_SESSION['sessionAccess'] !="Oui"){
	
                header("location:../index.php"); 
	
}
 include('../include/connexion.php') ;
 include('../Controller/Patient.php');
 include('../Manager/PatientManager.php');

$manager =new PatientManager($pdo);
$patients=$manager->Affich();

?>

<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<?php include('../include/headhtml.php'); ?>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-container-bg-solid page-content-white page-md">
    <div class="page-wrapper">
        <!-- start header -->
        <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
                <!-- logo start -->
                <div class="page-logo">
                    <a href="../home/Dashboard.php">
                        <img src="../web/img/logo.png" alt="logo" class="logo-default" /> </a>
                    <div class="menu-toggler sidebar-toggler">
                        <span></span>
                    </div>
                </div>
                <!-- logo end -->
                 <form class="search-form-opened" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search..." name="query">
                        <span class="input-group-btn">
                          <a href="javascript:;" class="btn submit">
                             <i class="icon-magnifier"></i>
                           </a>
                        </span>
                    </div>
                </form>
                <!-- start mobile menu -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
               <!-- end mobile menu -->
                <!-- start header menu -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                    	
						<!-- start language menu -->
                        <?php include('../include/langueMenu.php'); ?>
                        <!-- end language menu -->
                        
						<!-- start notification dropdown -->
						<?php include('../include/dropDownNotification.php'); ?>
                        <!-- end notification dropdown -->
                        
						<!-- start message dropdown -->
 						<?php include('../include/dropdownMessage.php'); ?>
                        <!-- end message dropdown -->
 						
						<!-- start manage user dropdown -->
						<?php include('../include/userDropdown.php'); ?>
 						<!-- end manage user dropdown -->
						
 						<li class="dropdown dropdown-quick-sidebar-toggler">
                            <a href="javascript:;" class="dropdown-toggle">
                                <i class="icon-logout"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end header -->
        <div class="clearfix"> </div>
        <!-- start page container -->
        <div class="page-container">
 			
			<!-- start sidebar menu -->
            <?php include('../include/boxSideMenu.php'); ?>
 			<!-- end sidebar menu --> 
			
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Dashboard</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Dashboard</li>
                            </ol>
                        </div>
                    </div>
                   <!-- start widget -->
					<?php include('../include/widget.php'); ?>
				   <!-- end widget -->
                     
					 <!-- chart start -->
                    <div class="row">
					
					<!--A ajouter block Statistics ici -->
					<?php //include ('include/boxStatistique1.php'); ?>
                    </div>
                     <!-- Chart end -->
                    
					<!--BOOKED APPOINTMENT Start ex placement-->
					<!--BOOKED APPOINTMENT End-->
					
                    <!-- start admited patient list -->
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="card  card-topline-yellow">
                                <div class="card-head">
                                    <header>ADMIT PATIENT LIST</header>
                                    <div class="tools">
                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
	                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
	                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                                    </div>
                                </div>
                                <div class="card-body ">
                                  <div class="table-wrap">
										<div class="table-responsive">
											<table class="table display product-overview mb-30" id="support_table">
												<thead>
													<tr>
														<th>No</th>
														<th>Name</th>
														<th>Assigned Doctor</th>
														<th>Date Of Admit</th>
														<th>Diseases</th>
														<th>Room No</th>
														<th>Edit</th>
													</tr>
												</thead>
												<tbody>
                                                    
                                                           
                                                               
                                                          <?php 
                                                     
                                                     foreach ($patients as $unpatient) { 
													echo '<tr>
														<td>'.$unpatient->idPatient().'</td>
														<td><a href="../View/patient_profile.php?id_patient='.$unpatient->idPatient().'">'.$unpatient->nomPatient().'</td>
														<td>Dr.Kenny Josh</td>
														<td>27/05/2016</td>
														<td>
															<span class="label label-sm label-success">Influenza</span>
														</td>
														<td>101</td>
														<td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit" ><i class="fa fa-check"></i></a> <a href="javascript:void(0)" class="text-inverse" title="Delete" data-toggle="tooltip"><i class="fa fa-trash"></i></a></td>
													</tr>';}

                                                    ?>
                                                    
													
												</tbody>
											</table>
										</div>
									</div>	
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- end admited patient list -->
					
					<!--BOOKED APPOINTMENT Start nouveau placement-->
					<?php include ('../include/bookedAppointement.php'); ?>
					<!--BOOKED APPOINTMENT End-->
                </div>
            </div>
            <!-- end page content -->
            
			<!-- start chat sidebar -->
            <?php include ('../include/boxDocteurChat.php');?>
            <!-- end chat sidebar -->
			
        </div>
        <!-- end page container -->
        <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner">
            
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <script src="../web/js/jquery.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="../web/js/counterup/jquery.waypoints.min.js" type="text/javascript"></script>
    <script src="../web/js/counterup/jquery.counterup.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery.slimscroll.js"></script>
    <script src="../web/js/app.js" type="text/javascript"></script>
    <script src="../web/js/layout.js" type="text/javascript"></script>
    <script src="../web/js/chart-js/Chart.bundle.js" type="text/javascript"></script>
    <script src="../web/js/chart-js/utils.js" type="text/javascript"></script>
    <script src="../web/js/chart-js/home-data.js" type="text/javascript"></script>
    
    
  </body>
</html>