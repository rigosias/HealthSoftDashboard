
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/3.0.3/normalize.min.css">
	<link rel="stylesheet" href="http://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
	<link rel="stylesheet" href="dist/basicContext.min.css">
	<link rel="stylesheet" href="dist/themes/default.min.css">

	

	<a href="#" class="click">Click me!</a>

	<script src="dist/basicContext.min.js"></script>

	<script>

		var onClick = function(e) {

			var clicked = function() { alert('Item clicked!') }

			var onClose = function(e) {

				document.querySelector('a.click.active').classList.remove('active')

				basicContext.close()

			}

			this.classList.add('active')

			var items = [
				{ title: 'Add Sites', icon: 'ion-plus-round', fn: clicked },
				{ title: 'Reset Login', icon: 'ion-person', fn: clicked },
				{ title: 'Help', icon: 'ion-help-buoy', fn: clicked },
				{ title: 'Disabled', icon: 'ion-minus-circled', fn: clicked, disabled: true },
				{ title: 'Invisible', icon: 'ion-eye-disabled', fn: clicked, visible: false },
				{ },
				{ title: 'Logout', icon: 'ion-log-out', fn: clicked }
			]

			basicContext.show(items, e, onClose)

		}

		document.addEventListener('DOMContentLoaded', function() {

			document.querySelector('a.click').addEventListener('click', onClick)

		})

	</script>

