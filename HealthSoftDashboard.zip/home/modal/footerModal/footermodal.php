<style>
    body {font-family: Arial, Helvetica, sans-serif;}

    /* The Modal (background) */
    .modal {
        display: none; /* Hidden by default */
        position: fixed; /* Stay in place */
        z-index: 1; /* Sit on top */
        left: 0;
        top: 0;
        width: 100%; /* Full width */
        height: 100%; /* Full height */
        overflow: auto; /* Enable scroll if needed */
        background-color: rgb(0,0,0); /* Fallback color */
        background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        -webkit-animation-name: fadeIn; /* Fade in the background */
        -webkit-animation-duration: 0.4s;
        animation-name: fadeIn;
        animation-duration: 0.4s
    }

    /* Modal Content */
    .modal-content {
        position: fixed;
        bottom: 0;
        background-color: #149dcc;
        width: 100%;
        height: 200px;
        -webkit-animation-name: slideIn;
        -webkit-animation-duration: 0.4s;
        animation-name: slideIn;
        animation-duration: 0.4s
    }

    /* The Close Button */
    #close {
        color: white;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    #close:hover,
    #close:focus {
        color: #000;
        text-decoration: none;
        cursor: pointer;
    }

    .modal-header {
        padding: 2px 50%;
        background-color: #149dcc;
        color: #149dcc;
    }

    .modal-body {padding: 2px 16px;}

    .modal-footer {
        padding: 2px 16px;
        background-color: #149dcc;
        color: #149dcc;
    }

    /* Add Animation */
    @-webkit-keyframes slideIn {
        from {bottom: -300px; opacity: 0} 
        to {bottom: 0; opacity: 1}
    }

    @keyframes slideIn {
        from {bottom: -300px; opacity: 0}
        to {bottom: 0; opacity: 1}
    }

    @-webkit-keyframes fadeIn {
        from {opacity: 0} 
        to {opacity: 1}
    }

    @keyframes fadeIn {
        from {opacity: 0} 
        to {opacity: 1}
    }
</style>

<!-- <h2>Bottom Modal</h2> -->

<!-- Trigger/Open The Modal -->
<!-- <button id="click">Open Modal</button> -->

<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <span id="close"> <b>&times;</b> </span>      
    </div>
    <div class="modal-body">
   
        <section class="mbr-section content8 cid-qNOERsL5bu" id="content8-t">    

            <div class="container">
                <div class="media-container-row title">
                    <div class="col-12 col-md-8">
                        <div class="mbr-section-btn align-center">
                            

                            <?php  if (!isset($_SESSION['username'])) : ?>

                                

                            <?php endif ?>

                            <?php  if (isset($_SESSION['username'])) : ?>

                                <p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>              

                                <a class="btn btn-sm btn-secondary display-7" href="../logout.php?logout='1'" style="color: white;">
                                    <span class="btn-icon mbri-mobile mbr-iconfont mbr-iconfont-btn">
                                    </span>
                                    LogOut
                                </a>

                            <?php endif ?>

                            <a class="btn btn-sm btn-secondary display-7" href="index.html">
                                <span class="btn-icon mbri-mobile mbr-iconfont mbr-iconfont-btn" style="color: white;">
                                </span>
                                Help
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
   
            

    </div>
    <div class="modal-footer">      
    </div>
  </div>

</div>

<script>
    // Get the modal
    var modal = document.getElementById('myModal');

    // Get the button that opens the modal
    var btn = document.getElementById("click");

    // Get the <span> element that closes the modal
    var span = document.getElementById("close");

    // When the user clicks the button, open the modal 
    btn.onclick = function() {
        modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
</script>
