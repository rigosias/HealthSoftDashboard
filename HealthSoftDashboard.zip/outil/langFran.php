<?php

$tab[0]="Ajouter Patient"; 
$tab[1]="Modifier Patient";

echo $tab[0];


?>