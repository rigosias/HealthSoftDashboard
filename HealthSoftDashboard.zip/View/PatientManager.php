<?php

class PatientManager{

	private $_pdo;
	
	public function __construct($pdo) {
		$this->setDb($pdo);
		
	}
	
	
  
   public function add(Patient $patient)
	{
		$q=$this->_pdo->prepare('INSERT INTO patient(nomPatient,prenomPatient,codeNationalPatient,codeAttribueParLeSite,
		sexePatient,communePatient,telephonePatient,lieuNaissancePatient,localitePatient,agePatient,professionPatient,
		prenomMerePatient,statutMaritalPatient,nomPrenomUrgence,adresseUrgence,foneUrgence,nomResp1,lienResp1,adresseResp1,
		foneResp1,nomResp2,lienResp2,adresseResp2,foneResp2,nomPrenomAutEnfant,lienParenteEnfant, adresseAutEnfant,
		telephoneAutEnfant,idhopital,userid) 
		VALUES(:nomPatient,:prenomPatient,:codeNationalPatient,:codeAttribueParLeSite,:sexePatient,:communePatient,
		:telephonePatient,:lieuNaissancePatient,:localitePatient,:agePatient,:professionPatient,:prenomMerePatient,
		:statutMaritalPatient,:nomPrenomUrgence,:adresseUrgence,:foneUrgence,:nomResp1,:lienResp1,:adresseResp1,:foneResp1,
		:nomResp2,:lienResp2,:adresseResp2,:foneResp2,:nomPrenomAutEnfant,:lienParenteEnfant,:adresseAutEnfant,
		:telephoneAutEnfant,:idhopital,:userid)');
		$q->bindValue(':nomPatient',$patient->nomPatient());
		$q->bindValue(':prenomPatient',$patient->prenomPatient());
		$q->bindValue(':codeNationalPatient',$patient->codeNationalPatient());
		$q->bindValue(':codeAttribueParLeSite',$patient->codeAttribueParLeSite());
		$q->bindValue(':sexePatient',$patient->sexePatient());
		$q->bindValue(':communePatient',$patient->communePatient());
		$q->bindValue(':telephonePatient',$patient->telephonePatient());
		$q->bindValue(':lieuNaissancePatient',$patient->lieuNaissancePatient());
		$q->bindValue(':localitePatient',$patient->localitePatient());
		$q->bindValue(':agePatient',$patient->agePatient());
		$q->bindValue(':professionPatient', $patient->professionPatient());
		$q->bindValue(':prenomMerePatient', $patient->prenomMerePatient());
		$q->bindValue(':statutMaritalPatient', $patient->statutMaritalPatient());
		$q->bindValue(':nomPrenomUrgence', $patient->nomPrenomUrgence());
		$q->bindValue(':adresseUrgence', $patient->adresseUrgence());
		$q->bindValue(':foneUrgence', $patient->foneUrgence());
		$q->bindValue(':nomResp1', $patient->nomResp1());
		$q->bindValue(':lienResp1', $patient->lienResp1());
		$q->bindValue(':adresseResp1', $patient->adresseResp1());
		$q->bindValue(':foneResp1', $patient->foneResp1());
		$q->bindValue(':nomResp2', $patient->nomResp2());
		$q->bindValue(':lienResp2', $patient->lienResp2());
		$q->bindValue(':adresseResp2', $patient->adresseResp2());
		$q->bindValue(':foneResp2', $patient->foneResp2());
		$q->bindValue(':nomPrenomAutEnfant', $patient->nomPrenomAutEnfant());
		$q->bindValue(':lienParenteEnfant', $patient->lienParenteEnfant());
		$q->bindValue(':adresseAutEnfant', $patient->adresseAutEnfant());
		$q->bindValue(':telephoneAutEnfant', $patient->telephoneAutEnfant());
		$q->bindValue(':idhopital', $_SESSION['HOPITAL_NAME']);
		$q->bindValue(':userid', $_SESSION['HOPITAL_NAME']);

	    $q->execute();
		
	} 
	public function Affich($user){
        $patients = [];

        $r = "SELECT * FROM patient where idhopital=\"".$user."\";";

		$q=$this->_pdo->query($r);
	  
	  echo $r;
		while ($donnees = $q->fetch(PDO::FETCH_ASSOC))
      {
       

      $patients []=  new patient($donnees);

      }

     return $patients;
	 }
	 
	 
	 
	 public function AffichUnPatient($info){
        $patients = [];

		
		$q=$this->_pdo->query('SELECT *  FROM patient WHERE idPatient='.$info);
	  
		while ($donnees = $q->fetch(PDO::FETCH_ASSOC))
      {
       
      $patients []=  new patient($donnees);

      }
     return $patients;
	 }

	public function count()

  {

    return $this->_db->query('SELECT COUNT(*) FROM patient')->fetchColumn();

  }	
	public function delete(Patient $patient)

  {

    $this->_db->exec('DELETE FROM personnages WHERE id = '.$patient->id());

  }	
		
		
	
  public function update(Patient $patient)

  {

    $q = $this->_db->prepare('UPDATE patient SET  WHERE id = :id');

    

    $q->bindValue(':degats', $perso->degats(), PDO::PARAM_INT);

    $q->bindValue(':id', $perso->id(), PDO::PARAM_INT);

    

    $q->execute();

  }	
	
	
	
	
  public function setDb(PDO $pdo)

 {

   $this->_pdo = $pdo;

  }
}




?>