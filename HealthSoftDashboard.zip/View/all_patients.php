<?php 

    include('../genuis_connection_login/accountManager/server.php');



    if ($_SESSION['aproved'] == "No"){
        
         header("location: ../index.php"); 
        
    }

     include('../include/connexion.php') ;
     include('../controller/Patient.php');
     include('../Manager/PatientManager.php');

    $manager=new PatientManager($pdo);

    $ki = $_GET['FOR_SEACH'];
    
    //$_SESSION['HOPITAL_NAME']
    $patients=$manager->Affich($ki);
   
        
   
    //$patients=$manager-> AffichUnPatient(1);

    //print_r($patients);
    //exit;
?>


<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->

    <?php include('../include/headhtml.php'); ?>

<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md">
    <div class="page-wrapper">
        <!-- start header -->
        <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
                <!-- logo start -->
               <div class="page-logo">
                    <a href="../home/Dashboard.php" id="centerHopitalName">                
                            <?php  echo $_SESSION['HOPITAL_NAME']; ?>                      
                    </a>
                    <style type="text/css">
                        #centerHopitalName {
                            margin-top: 15px;
                            text-align: center; 
                            font-size: 18px;
                            font-weight: bold; 
                            color: white;                        
                        }
                    </style>
                    <div class="menu-toggler sidebar-toggler">
                        <span></span>
                    </div>
                </div>
                <!-- logo end -->
                 <form class="search-form-opened" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search..." name="query">
                        <span class="input-group-btn">
                                <a href="javascript:;" class="btn submit">
                                    <i class="icon-magnifier"></i>
                                </a>
                            </span>
                    </div>
                </form>
                <!-- start mobile menu -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
               <!-- end mobile menu -->
                <!-- start header menu -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                    	
						<!-- start language menu -->
                        <?php include('../include/langueMenu.php'); ?>
                        <!-- end language menu -->
                        
						<!-- start notification dropdown -->
                       <?php include('../include/dropDownNotification.php'); ?>
                        <!-- end notification dropdown -->
                        
						<!-- start message dropdown -->
						<?php include('../include/dropdownMessage.php'); ?>
 						<!-- end message dropdown -->
 						
						<!-- start manage user dropdown -->
						<?php include('../include/userDropdown.php'); ?>
 						<!-- end manage user dropdown -->
						
 						<li class="dropdown dropdown-quick-sidebar-toggler">
                            <a href="javascript:;" class="dropdown-toggle">
                                <i class="icon-logout"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end header -->
        
		<div class="clearfix"> </div>
        <!-- start page container -->
        <div class="page-container">
 			<!-- start sidebar menu -->
 		<?php include('../include/boxSideMenu.php'); ?>
            <!-- end sidebar menu -->
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Patients List</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li><a class="parent-item" href="">Patients</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Patient List</li>
                            </ol>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="tabbable-line">
                                <ul class="nav nav-tabs">
                                    <li class="active">
                                        <a href="#tab1" data-toggle="tab"> List View </a>
                                    </li>
                                    <li>
                                        <a href="#tab2" data-toggle="tab"> Grid View </a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div class="tab-pane active fontawesome-demo" id="tab1">
                                        <div class="row">
					                        <div class="col-md-12">
					                            <div class="card card-topline-red">
					                                <div class="card-head">
					                                    <header> 
                                                            <form onsubmit="return false;" style="background-color: #1976d2;" class="search-form-opened"  >
                                                                    <div class="input-group">
                                                                        <input type="text" id="searchInput" class="form-control" placeholder="Search..." >
                                                                        <span class="input-group-btn">
                                                                                <a href="javascript:;" class="btn submit">
                                                                                    <i class="icon-magnifier"></i>
                                                                                </a>
                                                                            </span>
                                                                    </div>
                                                                </form>
                                                                <script type="text/javascript">
                                                                 
                                                                    var input = document.getElementById("searchInput");
                                                                    
                                                                    input.addEventListener("keyup", function(event) {
                                                                  
                                                                      event.preventDefault();
                                                                      
                                                                      if (event.keyCode === 13) {
                                                                        
                                                                        
                                                                        var qr = document.getElementById("searchInput").value;

                                                                        location.href = "all_patients.php?FOR_SEACH="+qr;

                                                                      }
                                                                    });
                                                                </script>
                                                        </header>
					                                    <div class="tools">
					                                        <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
						                                    <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
						                                    <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
					                                    </div>
					                                </div>
					                                <div class="card-body ">
					                                    <div class="row">
					                                        <div class="col-md-6 col-sm-6 col-xs-6">
					                                            <div class="btn-group">

					                                                <button id="addRow" class="btn btn-info">
					                                                    Add New <i class="fa fa-plus"></i>
					                                                </button>
					                                            </div>
					                                        </div>
					                                        <div class="col-md-6 col-sm-6 col-xs-6">
					                                            <div class="btn-group pull-right">
					                                                <button class="btn green-bgcolor  btn-outline dropdown-toggle" data-toggle="dropdown">Tools
					                                                    <i class="fa fa-angle-down"></i>
					                                                </button>
					                                                <ul class="dropdown-menu pull-right">
					                                                    <li>
					                                                        <a href="javascript:;">
					                                                            <i class="fa fa-print"></i> Print </a>
					                                                    </li>
					                                                    <li>
					                                                        <a href="javascript:;">
					                                                            <i class="fa fa-file-pdf-o"></i> Save as PDF </a>
					                                                    </li>
					                                                    <li>
					                                                        <a href="javascript:;">
					                                                            <i class="fa fa-file-excel-o"></i> Export to Excel </a>
					                                                    </li>
					                                                </ul>
					                                            </div>
					                                        </div>
					                                    </div>
					                                    <table class="table table-striped table-bordered table-hover table-checkable order-column valign-middle" id="example4">
					                                        <thead>
					                                            <tr>
					                                            	<th></th>
					                                                <th> Nom </th>
					                                                <th> Prenom </th>
					                                                <th> Age </th>
					                                               <th> Telephone </th>
					                                                <th> Lieu Naissance </th>
					                                                <th> Profession </th>
					                                                <th>Age</th>
					                                                <th>Sexe</th>
					                                                <th>Status</th>
					                                                <th> Action </th>
					                                            </tr>
					                                        </thead>
					                                         
                                                           
                                                            <tbody>
															<?php
                                                           
                                                               
                                                            
                                                            foreach ($patients as $unpatient) { 
    
                                                           

                                                            echo'<tr class="odd gradeX">
																	<td class="patient-img">
																			<img src="../web/img/user/user1.svg" alt="">
																	</td>
																	<td><a  onclick="getId()"> '.$unpatient->nomPatient().' </a></td>
																	<td class="center">'.htmlentities($unpatient->prenomPatient()).'</td>
																	<td class="center">'.$unpatient->agePatient().'</td>
																	<td>'.$unpatient->telephonePatient().' </td>
																                                   
																	<td>'.$unpatient->lieuNaissancePatient().' </td>
																			
																	<td class="center">'.$unpatient->ProfessionPatient().' </td>
																	<td class="center">'.$unpatient->agePatient().'</td>
																	<td class="center">'.$unpatient->sexePatient().'</td>
																	<td class="center">Discharge</td>
																	<td>
																		<button onclick="getId()" class="btn btn-primary btn-xs">
																			<i class="fa fa-pencil"></i>
																		</button>
																		
																		<script>  
																			function getId(){	
                                                                           											
																				location.href = "patient_profile.php?nom='.$unpatient->nomPatient().'&prenom='.$unpatient->prenomPatient().'&tel='.$unpatient->telephonePatient().'&adrs='.$unpatient->adresseUrgence().'";
																			}
																		</script>
																		
																		<button class="btn btn-danger btn-xs">
																			<i class="fa fa-trash-o "></i>
																		</button>
																	</td>
																</tr>';
                                                         }
                                                

                                                                 ?>

																
															</tbody>
					                                    </table>
					                                </div>
					                            </div>
					                        </div>
					                    </div>
                                    </div>
									<!-- start page tab patient 2 -->
                                    <?php include ('../include/boxAllPatient2.php');?>
									<!-- end page tab 2 patient -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page content -->
            <!-- start chat sidebar -->
            <?php include ('../include/boxDocteurChat.php');?>
            <!-- end chat sidebar -->
        </div>
        <!-- end page container -->
        <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner">
                
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="../web/js/jquery.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery.blockui.min.js" type="text/javascript"></script>
    <!-- bootstrap -->
    <script src="../web/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <!-- data tables -->
    <script src="../web/js/datatables/datatables.min.js" type="text/javascript"></script>
    <script src="../web/js/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
    <script src="../web/js/table_data.js" type="text/javascript"></script>
    
    <script src="../web/js/jquery.slimscroll.js"></script>
    <script src="../web/js/app.js" type="text/javascript"></script>
    <script src="../web/js/layout.js" type="text/javascript"></script>

    <?php include('../home/modal/footerModal/footermodal.php'); ?>
    
     <!-- end js include path -->
</body>
</html>