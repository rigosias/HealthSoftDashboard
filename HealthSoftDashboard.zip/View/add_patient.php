<?php
session_start();


include('../Manager/PatientManager.php');
include('../Controller/Patient.php');
include ('../include/connexion.php');


if(isset($_POST['submit'])){

        $nomPatient=$_POST['NomPatient'];
        $prenomPatient=$_POST['PrenomPatient'];
        $codeNationalPatient=$_POST['NoCodeNational'];
        $codeAttribueParLeSite=$_POST['NoAtrrSite'];
        $datevisite=$_POST['datevisite'];
        $sexePatient=$_POST['sexe'];
        $adresse=$_POST['adresse'];
        $communePatient=$_POST['commune'];
        $localitePatient=$_POST['localite'];
        $telephonePatient=$_POST['phone'];
        $lieuNaissancePatient=$_POST['lieuNaissance'];
        $datenaissance=$_POST['datenaissance'];
        $agePatient=$_POST['age'];
        $prenomMerePatient=$_POST['prenomMere'];
        $communePatient=$_POST['commune'];
        $commune=$_POST['commune'];
        //$professionPatient=$_POST[''];
        $statutMaritalPatient=$_POST['statutMere'];
        $nomPrenomUrgence=$_POST['nomPreUrg'];
        $adresseUrgence=$_POST['AddUrg'];
        $foneUrgence=$_POST['TelUrg'];
        $nomResp1=$_POST['nom1Respon'];
        $lienResp1=$_POST['Lien1Respon'];
        $adresseResp1=$_POST['AddUrg'];
        $foneResp1=$_POST['AddUrg'];
        $nomResp2=$_POST['nom2Respon'];
        $lienResp2=$_POST['Lien2Respon'];
        $adresseResp2=$_POST['AddUrg'];
        $foneResp2=$_POST['AddUrg'];
        $nomPrenomAutEnfant=$_POST['NomPrenomPersonneAut'];
        $lienParenteEnfant=$_POST['lienParentePerAutEnfant']; 
        $adresseAutEnfant=$_POST['adressePerAutEnfant'];
        $telephoneAutEnfant=$_POST['FonePerAutEnfant']; 


        $Manager = new PatientManager($pdo);
        
        $patient = new Patient(['nomPatient'=>"$nomPatient",
                                'prenomPatient'=>"$prenomPatient",
                                'codeNationalPatient'=>"$codeNationalPatient",
                                'codeAttribueParLeSite' =>"$codeAttribueParLeSite",
                                'sexePatient' =>"$sexePatient",
                                'communePatient' =>"$communePatient",
                                'telephonePatient' =>"$telephonePatient",
                                'lieuNaissancePatient'=>"$lieuNaissancePatient",
                                'localitePatient'=>"$localitePatient",
                                'agePatient'=>"$agePatient",
                                'professionPatient'=>"Ingenieur",
                                'prenomMerePatient'=>"$prenomMerePatient",
                                'statutMaritalPatient'=>"$statutMaritalPatient",
                                'nomPrenomUrgence'=>"$nomPrenomUrgence",
                                'adresseUrgence'=>"$adresseUrgence",
                                'foneUrgence'=>"$foneUrgence",
                                'nomResp1'=>"$nomResp1",
                                'lienResp1'=>"$lienResp1",
                                'adresseResp1'=>"$adresseResp1",
                                'foneResp1'=>"$foneResp1",
                                'nomResp2'=>"$nomResp2",
                                'lienResp2'=>"$lienResp2",
                                'adresseResp2'=>"$adresseResp2",
                                'foneResp2'=>"$foneResp2",
                                'nomPrenomAutEnfant'=>"$nomPrenomAutEnfant",
                                'lienParenteEnfant'=>"$lienParenteEnfant",
                                'adresseAutEnfant'=>"$adresseAutEnfant",
        'telephoneAutEnfant'=>"$telephoneAutEnfant"]);

        $Manager->add($patient);  }
        //echo $patient->nomPatient();

        //Patient::message();
      
?>



<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<?php include('../include/headhtml.php'); ?>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md">
    <div class="page-wrapper">
        <!-- start header -->
        <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
                <!-- logo start -->
                 <div class="page-logo">
                    <a href="#" id="centerHopitalName">                
                            <?php  echo $_SESSION['HOPITAL_NAME']; ?>                      
                    </a>
                    <style type="text/css">
                        #centerHopitalName {
                            margin-top: 15px;
                            text-align: center; 
                            font-size: 18px;
                            font-weight: bold; 
                            color: white;                        
                        }
                    </style>
                    <div class="menu-toggler sidebar-toggler">
                        <span></span>
                    </div>
                </div>
                <!-- logo end -->
                 <form class="search-form-opened" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search..." name="query">
                        <span class="input-group-btn">
                                <a href="javascript:;" class="btn submit">
                                    <i class="icon-magnifier"></i>
                                </a>
                            </span>
                    </div>
                </form>
                <!-- start mobile menu -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
               <!-- end mobile menu -->
                
				<!-- start header menu -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                    	
						<!-- start language menu -->
                        <?php include('../include/langueMenu.php'); ?>
                        <!-- end language menu -->
                        
						<!-- start notification dropdown -->
                        <?php include('../include/dropDownNotification.php'); ?>
                        <!-- end notification dropdown -->
                        
						<!-- start message dropdown -->
						<?php include('../include/dropdownMessage.php'); ?>
 					   <!-- end message dropdown -->
 						
						<!-- start manage user dropdown -->
						<?php include('../include/userDropdown.php'); ?>
 						<!-- end manage user dropdown -->
 						
						<li class="dropdown dropdown-quick-sidebar-toggler">
                            <a href="javascript:;" class="dropdown-toggle">
                                <i class="icon-logout"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end header -->
        <div class="clearfix"> </div>
        <!-- start page container -->
        <div class="page-container">
 			<!-- start sidebar menu -->
 			<?php include('../include/boxSideMenu.php');?>
            <!-- end sidebar menu -->
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Add Patient</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li><a class="parent-item" href="">Patients</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Add Patient</li>
                               
                            </ol>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="card card-topline-aqua" id="form_wizard_1">
                                <div class="card-head">
                                </div>
                                <div class="card-body" id="bar-parent">
                                <form class="form-horizontal" action="" id="submit_form" method="POST">
                                        <div class="form-wizard">
                                            <div class="form-body">
                                                <ul class="nav nav-pills nav-justified steps">
                                                    <li>
                                                        <a href="#tab1" data-toggle="tab" class="step">
                                                            <span class="number"> 1 </span>
                                                            <span class="desc">
                                                                    Basic
                                                             </span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#tab2" data-toggle="tab" class="step">
                                                            <span class="number"> 2 </span>
                                                            <span class="desc">
                                                                    Physical
                                                            </span>
                                                        </a>
                                                    </li>
                                                     <li>
                                                        <a href="#tab3" data-toggle="tab" class="step active">
                                                            <span class="number"> 3 </span>
                                                            <span class="desc">
                                                                    Assign Doctor </span>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="#tablast" data-toggle="tab" class="step active">
                                                            <span class="number"> 4 </span>
                                                            <span class="desc">
                                                                    Verify Details </span>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <div id="bar" class="progress progress-striped" role="progressbar">
                                                    <div class="progress-bar progress-bar-info"> </div>
                                                </div>
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="tab1">
                                                        <h3 class="block">Ministere Sante Publique</h3>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3" >Nom Patient
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Nom Patient" name="NomPatient" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Prenom Patient
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Prenom Patient" name="PrenomPatient" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">No.de code national du patient
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="No Code national Patient" name="NoCodeNational" />
                                                            </div>
                                                        </div>
														
														<?php include('../genuis_connection_login/generate.php'); ?>
														<div class="form-group">
                                                            <label class="control-label col-md-3">No.de patient attribue par le site
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="No attribue par le site" readonly value="<?php echo $generatedCode; ?>" name="NoAtrrSite" />
                                                            </div>
                                                        </div>
                                                        
														<div class="form-group">
			                                                <label class="control-label col-md-3">Date de visite
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <div class="" >
					                                                <input class="form-control input-height" name="datevisite" placeholder="date de visite" size="16" type="text" value="<?php echo date('Y-m-d'); ?>" readonly>
					                                                
					                                                
					                                            </div>
			                                            		<input type="hidden" value="" />
			                                                </div>
			                                            </div>
														 

			                                            <div class="form-group">
			                                                <label class="control-label col-md-3">Sexe
			                                                    <span class="required"> * </span>
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <select class="form-control input-height" name="sexe">
			                                                        <option value="">Select...</option>
			                                                        <option value="Masculin">Male</option>
			                                                        <option value="Feminin">Female</option>
			                                                    </select>
			                                                </div>
															
															
														
			                                                   </div>
															   <div class="form-group">
                                                            <label class="control-label col-md-3">Adresse
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Adresse" name="adresse" />
                                                            </div>
                                                        </div>
														
														 <div class="form-group">
                                                            <label class="control-label col-md-3">Commune
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Commune" name="commune" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Localite
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="localite" name="localite" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
			                                              <label class="control-label col-md-3">Telephone
			                                                    <span class="required"> * </span>
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <input name="phone" type="" class="form-control input-height" placeholder="phone" name="phone" /> </div>
			                                            </div>
														
														
														<div class="form-group">
			                                              <label class="control-label col-md-3">Lieu de Naissance
			                                                    <span class=""> * </span>
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <input name="lieuNaissance" type="text" class="form-control input-height" placeholder="Lieu de Naissance" name="lieuNaissance" /> </div>
			                                            </div>
														
														<div class="form-group">
			                                                <label class="control-label col-md-3">Date de Naissance
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <div   class="input-group date form_date " data-date="" data-date-format="dd MM yyyy" data-link-field="dtp_input2" data-link-format="yyyy-mm-dd" >
					                                                <input id="datepicker" class="form-control input-height" name="datenaissance" placeholder="date of birth" size="16" type="text" value="" >
					                                                <span class="input-group-addon"><span class="glyphicon glyphicon-remove"></span></span>
					                                                <span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>
					                                            </div>
			                                            		<input type="hidden" id="dtp_input5" value="" />
			                                                </div>
			                                            </div>
															
														
														
													
														
			                                            <div class="form-group">
			                                                <label class="control-label col-md-3">Age en Annee
			                                                    <span class="required"> * </span>
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <input name="age" id="age_2" type="text" class="form-control input-height" placeholder="age" /> </div>
			                                            </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Prenom de la Mere
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Prenom de la mere" name="prenomMere" />
                                                            </div>
                                                        </div>

			                                           
			                                            
			                                            <div class="form-group">
			                                                <label class="control-label col-md-3">Statut Marital Mere
			                                                    <span class="required"> * </span>
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <select class="form-control input-height" name="statutMere">
			                                                        <option value="">Select...</option>
			                                                        <option value="Category 1">Mariee</option>
			                                                        <option value="Category 2">Concubinage</option>
																	<option value="Category 3">veuf(ve)</option>
																	<option value="Category ">Separe(e)</option>
																	<option value="Category ">Celibataire</option>
																	<option value="Category ">Inconnu</option>
			                                                    </select>
			                                                </div>
			                                            </div>
													
														
														
														<h5 class="block">PERSONNE AUTORISEE PAR LA LOI A PRENDRE DES DECISIONS MEDICALES POUR LE PATIENT 
                                                             </h5>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Nom et Prenom
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="nom et prenom" name="NomPrenomPersonneAut" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Lien de parente avec l'enfant
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Lien de parente avec l'enfant" name="lienParentePerAutEnfant" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Adresse
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Adresse" name="adressePerAutEnfant" />
                                                            </div>
                                                        </div>
														
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Telephone
                                                                <span class="required"> * </span>
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Telephone" name="FonePerAutEnfant" />
                                                            </div>
                                                        </div>
                                                       <div class="form-group">
                                                            <label class="control-label col-md-3">Upload Photo
                                                            </label>
                                                            <div class="col-md-5">
																<div id="id_dropzone" class="dropzone"></div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tab2">
                                                        <h3 class="block">CONTACT EN CAS DURGENCE</h3>
														
														
                                                        
			                                            <div class="form-group">
                                                            <label class="control-label col-md-3">Nom et Prenom
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Nom et Prenom" name="nomPreUrg" />
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Adresse
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Adresse" name="AddUrg" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Telephone
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Telefone" name="TelUrg" />
                                                            </div>
                                                        </div>
														<h5 class="block">NOM PERSONNE RESPONSABLES AVEC LESQUELLES NOUS POUVONS DISCUTER DE VOTRE ETAT DE SANTE AU BESOIN</h5>
                                                        
														<div class="form-group">
                                                            <label class="control-label col-md-3">1.Nom 
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Nom 1" name="nom1Respon" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Lien
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Lien 1" name="Lien1Respon" />
                                                            </div>
                                                        </div> 
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">2.Nom 
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Nom 2" name="nom2Respon" />
                                                            </div>
                                                        </div>
														
														<div class="form-group">
                                                            <label class="control-label col-md-3">Lien 
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Lien 2" name="Lien2Respon" />
                                                            </div>
                                                        </div>
														
                                                    </div>
                                                    <div class="tab-pane" id="tab3">
                                                        <h3 class="block">Provide Doctor details</h3>
                                                        <div class="form-group">
			                                                <label class="control-label col-md-3">Assign Doctor
			                                                    <span class="required"> * </span>
			                                                </label>
			                                                <div class="col-md-5">
			                                                    <select class="form-control input-height" name="selectdoctor">
			                                                        <option value="">Select...</option>
			                                                        <option value="Category 1">Dr.Rajesh</option>
			                                                        <option value="Category 2">Dr.Pooja Patel</option>
			                                                        <option value="Category 3">Dr.Sarah Smith</option>
			                                                        <option value="Category 4">Dr.John Deo</option>
			                                                        <option value="Category 5">Dr.Jay Soni</option>
			                                                        <option value="Category 6">Dr.Jacob Ryan</option>
			                                                        <option value="Category 7">Dr.Megha Trivedi</option>
			                                                    </select>
			                                                </div>
			                                            </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Consulting Room No
                                                            </label>
                                                            <div class="col-md-5">
                                                                <input type="text" class="form-control input-height" placeholder="Consulting Room No" name="roonNo" />
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="tab-pane" id="tablast">
                                                        <h3 class="block">Verify your details</h3>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Name:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="doctorname"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Email:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="email"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Date Of Birth:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="dateofbirth"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Address:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="adresse"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Phone:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="phone"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Blood Group:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="selectbg"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Blood Presure:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="bp"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Injury/Condition:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="injury"> </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label class="control-label col-md-3">Assign Doctor:</label>
                                                            <div class="col-md-5">
                                                                <p class="form-control-static" data-display="selectdoctor"> </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-actions">
                                                <div class="row">
                                                    <div class="col-md-offset-3 col-md-9">
                                                        <a href="javascript:;" class="btn btn-outline green-bgcolor  button-previous">
                                                            <i class="fa fa-angle-left"></i> Previous </a>
                                                        <a href="javascript:;" class="btn btn-outline green-bgcolor button-next"> Next
                                                                <i class="fa fa-angle-right"></i>
                                                            </a>
                                                        <input type="submit" value="Finish" name="submit" href="javascript:;" class="btn btn-outline green-bgcolor button-submit"  />

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page content -->
            <!-- start chat sidebar -->
            <?php include ('../include/boxDocteurChat.php');?>
            <!-- end chat sidebar -->
        </div>
        <!-- end page container -->
        <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner">
                
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="../web/js/jquery.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
    <!-- bootstrap -->
    <script src="../web/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-wizard/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-timepicker/js/bootstrap-timepicker-init.js" type="text/javascript" charset="UTF-8"></script>
    
	<!-- dropzone -->
    <script src="../web/js/dropzone/dropzone.js" type="text/javascript"></script>
    <script src="../web/js/dropzone/dropzone-call.js" type="text/javascript"></script>
    
    <script src="../web/js/jquery.slimscroll.js"></script>
    <script src="../web/js/app.js" type="text/javascript"></script>
    <script src="../web/js/form-wizard.js" type="text/javascript"></script>
    <script src="../web/js/layout.js" type="text/javascript"></script>
    
    
     <!-- end js include path -->
</body>
</html>