<?php include('../genuis_connection_login/accountManager/server.php'); ?>
<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>

    <?php include('../include/headhtml.php'); ?>
    
</head>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md">
    <div class="page-wrapper">
        <!-- start header -->
         <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
                <!-- logo start -->
                <div class="page-logo">
                    <a href="../home/Dashboard.php" id="centerHopitalName">                
                            <?php  echo $_SESSION['HOPITAL_NAME']; ?>                      
                    </a>
                    <style type="text/css">
                        #centerHopitalName {
                            margin-top: 15px;
                            text-align: center; 
                            font-size: 18px;
                            font-weight: bold; 
                            color: white;                        
                        }
                    </style>
                    <div class="menu-toggler sidebar-toggler">
                        <span></span>
                    </div>
                </div>
                <!-- logo end -->
                 <form class="search-form-opened" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search..." name="query">
                        <span class="input-group-btn">
                          <a href="javascript:;" class="btn submit">
                             <i class="icon-magnifier"></i>
                           </a>
                        </span>
                    </div>
                </form>
                <!-- start mobile menu -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
               <!-- end mobile menu -->
                <!-- start header menu -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                        
                        <!-- start language menu -->
                        <?php include('../include/langueMenu.php'); ?>
                        <!-- end language menu -->
                        
                        <!-- start notification dropdown -->
                        <?php include('../include/dropDownNotification.php'); ?>
                        <!-- end notification dropdown -->
                        
                        <!-- start message dropdown -->
                        <?php include('../include/dropdownMessage.php'); ?>
                        <!-- end message dropdown -->
                        
                        <!-- start manage user dropdown -->
                        <?php include('../include/userDropdown.php'); ?>
                        <!-- end manage user dropdown -->
                        
                        <li class="dropdown dropdown-quick-sidebar-toggler">
                            <a href="#" class="dropdown-toggle">
                                <i class="icon-logout"  ></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end header -->
        <div class="clearfix"> </div>
        <!-- start page container -->
        <div class="page-container">
 			<!-- start sidebar menu -->
            <?php include('../include/boxSideMenu.php'); ?>
 			

            <!-- end sidebar menu -->
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Add Consultation</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li><a class="parent-item" href="">Consultations</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Add Consultation</li>
                            </ol>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="card card-topline-aqua" id="form_wizard_1">
                                <div class="card-head">
                                </div>
                                <div class="card-body" id="bar-parent">

                                <div class="container2">

                <form class="form-horizontal" action="../manager/TraitementConsultationAdulte.php" id="submit_form" method="POST">
                                        
                                        <div class="row">
                          <div class="col-50">

                            <h3> Consultation Adulte </h3>

                            <label for="fname"><i class="fa fa-user"></i> Code national du patient</label>
                            <input type="text" id="fname" name="code_national" value="" >

                            <?php include('../genuis_connection_login/generate.php'); ?>

                            <label for="fname"><i class="fa fa-user"></i> Code du system </label>
                            <input type="text" id="fname" name="code_attrib" readonly value="<?php echo $generatedCode; ?>" >

                            <label for="fname"><i class="fa fa-user"></i> Nom </label>
                            <input type="text" id="fname" name="nom" placeholder="Kendly" value="" >

                            <label for="email"><i class="fa fa-envelope"></i> Prenom</label>
                            <input type="text" id="email" name="prenom"  value="">

                            <label for="adr"><i class="fa fa-address-card-o"></i> Age </label>
                            <input type="text" id="adr" name="age"  value="">   

                            <label ><i class="fa fa-intersex"> </i> Sexe </label>
                                    <select name="sexe" >
                                      <option selected>M</option>
                                      <option value="1">F</option>                                
                                    </select>                

                            <label > Groupe Sanguin </label>
                                      <select name="group_sanguin" >
                                      <option>A+</option>
                                      <option>A-</option>
                                      <option>B+</option>
                                      <option>B-</option>   
                                      <option>O+</option>
                                      <option>O-</option>   
                                      <option>AB+</option>
                                      <option>AB-</option>  
                                      <option>Inconnu</option>                    
                                    </select>
                            

                             <label > Electrophorèse de l'emoglobine </label>
                                    <select name="analyse" >
                                     <option>AB</option>
                                     <option>SS</option>
                                     <option>SC</option>
                                     <option>AA</option>
                                     <option>Inconnu</option>                                                                 
                                    </select>
                            <label > Autre? precisez</label>
                                <input type="text" name="autres_1">
                             
                                    <label > Depistage CA du Col </label>
                                    <input type="date" name="depistage_ca_col">

                                    <label > Depistage CA de la prostate </label>
                                    <input type="date" name="depistage_ca_prostate">

                                    <label > Resultat </label>
                                    <textarea name="depistage_ca_prostate_2">
                                        
                                    </textarea>
                            
                            <h3>Antecedent HEREDO-COLLATEREAUX</h3>

                           
                                    <label > Asthme</label>
                                    <select name="asthme_fam" >
                                      <option selected>Mere</option>
                                      <option value="1">Pere</option>
                                      <option value="2">Fere</option>
                                      <option value="3">Soeur</option>
                                    </select>
                                 
                            
                              
                                <label > Cancer </label>
                                    <select name="cancer_fam" >
                                      <option selected>Mere</option>
                                      <option value="1">Pere</option>
                                      <option value="2">Fere</option>
                                      <option value="3">Soeur</option>
                                    </select>
                                    <label > Precisez </label>
                                    <input type="text" id="zip" name="cancer_fam_2" >
                             

                         
                                 <label > Cardiopathie </label>
                                    <select name="cardiopathie_fam" >
                                      <option selected>Mere</option>
                                      <option value="1">Pere</option>
                                      <option value="2">Fere</option>
                                      <option value="3">Soeur</option>
                                    </select>
                             

                                 <label > Diabète </label>
                                    <select name="diabete_fam" >
                                      <option selected>Mere</option>
                                      <option value="1">Pere</option>
                                      <option value="2">Fere</option>
                                      <option value="3">Soeur</option>
                                    </select>
                            

                                 <label > Epilepsie </label>
                                    <select name="epilepsie_fam" >
                                      <option selected>Mere</option>
                                      <option value="1">Pere</option>
                                      <option value="2">Fere</option>
                                      <option value="3">Soeur</option>
                                    </select>
                              
                                 <label > HTA </label>
                                    <select name="HTA_fam" >
                                      <option selected>Mere</option>
                                      <option value="1">Pere</option>
                                      <option value="2">Fere</option>
                                      <option value="3">Soeur</option>
                                    </select>
                              
                                 <label > Turbeculose </label>
                                    <select name="turbeculose_fam" >
                                      <option selected>Mere</option>
                                      <option value="1">Pere</option>
                                      <option value="2">Fere</option>
                                      <option value="3">Soeur</option>
                                    </select>

                                <label > Autres </label>
                                    <input type="text"  name="autres_2" > 

                              <h3>Antecedents personnels/ Habitudes</h3>

                           
                                 <label > Accident cerebro-vasculaire </label>                               
                                    <select name="accident_cere_vasc" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select>
                             
                                <label > Allergies </label>                              
                                    <select name="allergies" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 
                                    <label > Precisez </label>
                                    <input type="text"  name="allergies_2" > 

                                <label > Asthme </label>                              
                                    <select name="asthme_pers" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 
                                                          
                             
                                <label > Cancer </label>                             
                                    <select name="cancer_pers" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 
                                    <label > Precisez </label>
                                    <input type="text"  name="cancer_pers_2" >                            
                            
                                <label > Chirurgies / Trauma </label>                            
                                    <select name="chirurgie_trauma" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 
                                    <label > Precisez </label>
                                    <input type="text"  name="chirurgie_trauma_2" >                            
                              
                                <label > Cardiopathie </label>                               
                                    <select name="cardiopathie" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select>                                                         
                              
                                <label > Grossesse </label>                              
                                    <select name="grossesse" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select>                                                         
                              
                                    <label > Hypercholesteromelie </label>                               
                                    <select name="hypercholesteromie" >
                                      <option selected>NON enrolé en soin</option>
                                      <option value="1">Enrolé en soin</option>                                                
                                    </select>                     
                                                                                                

                                    <label > Diabète </label>                            
                                    <select name="diabete_pers" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>                                                               

                                    <label > Epilepsie </label>                              
                                    <select name="epilepsie_pers" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>                                                                                     
                              
                                    <label > Hemoglobinopathie </label>                              
                                    <select name="hemoglobinopathie" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 
                                    <label > Precisez </label>
                                    <input type="text"  name="hemoglobinopathie_2" >                            
                             
                                    <label > HTA </label>                            
                                    <select name="hta_pers" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>                                                                                     
                           
                                    <label > IST </label>                            
                                    <select name="ist" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 
                                    <label > Precisez </label>
                                    <input type="text"  name="ist_2" >                            
                             
                                    <label > Malnutrition / Perte de poids </label>                              
                                    <select name="malnutrition" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>                                                                                     
                               
                                    <label >  Malaria <= 1 mois </label>                             
                                    <select name="malarie_moins_1_mois" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>                                                                                     
                               
                                    <label >  Malaria >= 1 mois </label>                             
                                    <select name="malaria_plus_1_mois" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>                                                                                     
                               
                                    <label > Troubles psychiatriques </label>                            
                                    <select name="trouble_psychyatriques" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 
                                    <label > Precisez </label>
                                    <input type="text"  name="trouble_psychyatriques_2" >                            
                              
                                    <label > Alcool </label>                             
                                    <select name="alcool" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>                                                                                     
                             
                                    <label > Drogue </label>                             
                                    <select name="drogue" >
                                      <option selected>OUI</option>
                                      <option value="1">NON</option>                                  
                                    </select> 

                                    <label > Precisez </label>
                                    <input type="text"  name="drogue_2" >                            
                               
                                    <label > Tabac </label>                              
                                    <select name="tabac" >
                                      <option selected>OUI</option>
                                      <option value="1">Non</option>                                                          
                                    </select>

                                    <label > Autre / Precisez </label>                              
                                    <textarea name="autres_3" > </textarea>                                                                                      
                               
                                    <label > Medicaments actuel </label>                             
                                    <textarea name="medicaments_actuels"> 
                                        
                                    </textarea> 

                                    <label > Autres / Remarque </label>                              
                                    <textarea name="autres_4" >
                                        
                                    </textarea> 

                                    <h3> Signes Vitaux / Anthropometrie</h3>

                                    <label > Poids </label>
                                    <input type="text"  name="poids" >

                                    <label > TA </label>
                                    <input type="text"  name="ta" >

                                    <label > Taille </label>
                                    <input type="text"  name="taille" >

                                    <label > Temp </label>
                                    <input type="text"  name="temp" >

                                    <label > Pouls </label>
                                    <input type="text"  name="pouls" >

                                    <label > FR </label>
                                    <input type="text"  name="fr" >

                                    <label > IMC  </label>
                                    <input type="text"  name="imc" >


                                    <label > <i class="fa fa-user-circle-o"> Nom et Prenom du prestataire </i>  </label>
                                    <input type="text"  name="nom_Prenom_prestataire" >


                                </div>



                            </div>              

                                     <input type="submit" name="" class="btn btn-outline green-bgcolor" >

                                </form>
                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page content -->
            <!-- start chat sidebar -->
            <div class="chat-sidebar-container" data-close-on-body-click="false">
                <div class="chat-sidebar">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a href="javascript:;" data-target="#quick_sidebar_tab_1" data-toggle="tab"> Users
                                    <span class="badge badge-danger">4</span>
                                </a>
                        </li>
                        <li>
                            <a href="javascript:;" data-target="#quick_sidebar_tab_3" data-toggle="tab"> <i class="icon-settings"></i> Settings
                            </a>
                        </li>
                    </ul>
                    
                    <div class="tab-content">
                        <!-- Start Doctor Chat --> 
 						<div class="tab-pane active chat-sidebar-chat" id="quick_sidebar_tab_1">
                        	<div class="chat-sidebar-list">
	                            <div class="chat-sidebar-chat-users slimscroll-style" data-rail-color="#ddd" data-wrapper-class="chat-sidebar-list">
	                                <h3 class="list-heading">Online</h3>
	                                <ul class="media-list list-items">
	                                    <li class="media"><img class="media-object" src="img/doc/doc3.svg" width="35" height="35" alt="...">
	                                        <i class="online dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">John Deo</h4>
	                                            <div class="media-heading-sub">Spine Surgeon</div>
	                                        </div>
	                                    </li>
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-success">5</span>
	                                        </div> <img class="media-object" src="img/doc/doc1.svg" width="35" height="35" alt="...">
	                                        <i class="busy dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Rajesh</h4>
	                                            <div class="media-heading-sub">Director</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc5.svg" width="35" height="35" alt="...">
	                                        <i class="away dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Jacob Ryan</h4>
	                                            <div class="media-heading-sub">Ortho Surgeon</div>
	                                        </div>
	                                    </li>
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-danger">8</span>
	                                        </div> <img class="media-object" src="img/doc/doc4.svg" width="35" height="35" alt="...">
	                                        <i class="online dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Kehn Anderson</h4>
	                                            <div class="media-heading-sub">CEO</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc2.svg" width="35" height="35" alt="...">
	                                        <i class="busy dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Sarah Smith</h4>
	                                            <div class="media-heading-sub">Anaesthetics</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc7.svg" width="35" height="35" alt="...">
	                                        <i class="online dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Vlad Cardella</h4>
	                                            <div class="media-heading-sub">Cardiologist</div>
	                                        </div>
	                                    </li>
	                                </ul>
	                                <h3 class="list-heading">Offline</h3>
	                                <ul class="media-list list-items">
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-warning">4</span>
	                                        </div> <img class="media-object" src="img/doc/doc6.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Jennifer Maklen</h4>
	                                            <div class="media-heading-sub">Nurse</div>
	                                            <div class="media-heading-small">Last seen 01:20 AM</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc8.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Lina Smith</h4>
	                                            <div class="media-heading-sub">Ortho Surgeon</div>
	                                            <div class="media-heading-small">Last seen 11:14 PM</div>
	                                        </div>
	                                    </li>
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-success">9</span>
	                                        </div> <img class="media-object" src="img/doc/doc9.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Jeff Adam</h4>
	                                            <div class="media-heading-sub">Compounder</div>
	                                            <div class="media-heading-small">Last seen 3:31 PM</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc10.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Anjelina Cardella</h4>
	                                            <div class="media-heading-sub">Physiotherapist</div>
	                                            <div class="media-heading-small">Last seen 7:45 PM</div>
	                                        </div>
	                                    </li>
	                                </ul>
	                            </div>
                            </div>
                            <div class="chat-sidebar-item">
                                <div class="chat-sidebar-chat-user">
                                    <div class="page-quick-sidemenu">
                                        <a href="javascript:;" class="chat-sidebar-back-to-list">
                                            <i class="fa fa-angle-double-left"></i>Back
                                        </a>
                                    </div>
                                    <div class="chat-sidebar-chat-user-messages">
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:10</span>
                                                <span class="body-out"> could you send me menu icons ? </span>
                                            </div>
                                        </div>
                                        <div class="post in">
                                            <img class="avatar" alt="" src="img/doc/doc5.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:10</span>
                                                <span class="body"> please give me 10 minutes. </span>
                                            </div>
                                        </div>
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:11</span>
                                                <span class="body-out"> ok fine :) </span>
                                            </div>
                                        </div>
                                        <div class="post in">
                                            <img class="avatar" alt="" src="img/doc/doc5.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:22</span>
                                                <span class="body">Sorry for
													the delay. i sent mail to you. let me know if it is ok or not.</span>
                                            </div>
                                        </div>
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:26</span>
                                                <span class="body-out"> it is perfect! :) </span>
                                            </div>
                                        </div>
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:26</span>
                                                <span class="body-out"> Great! Thanks. </span>
                                            </div>
                                        </div>
                                        <div class="post in">
                                            <img class="avatar" alt="" src="img/doc/doc5.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:27</span>
                                                <span class="body"> it is my pleasure :) </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="chat-sidebar-chat-user-form">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Type a message here...">
                                            <div class="input-group-btn">
                                                <button type="button" class="btn green-bgcolor">
                                                    <i class="fa fa-arrow-right"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Doctor Chat --> 
 						<!-- Start Setting Panel --> 
 						<div class="tab-pane chat-sidebar-settings" id="quick_sidebar_tab_3">
                            <div class="chat-sidebar-settings-list">
                                <h3 class="list-heading">Layout Settings</h3>
	                            <div class="chatpane inner-content ">
	                            	<ul class="list-items borderless theme-options">
                                        <li class="theme-option layout-setting"><span>Sidebar
												Position </span>
                                            <select class="sidebar-pos-option form-control input-inline input-sm input-small ">
                                                <option value="left" selected="selected">Left</option>
                                                <option value="right">Right</option>
                                            </select>
                                        </li>
                                        <li class="theme-option layout-setting"><span>Header</span>
                                            <select class="page-header-option form-control input-inline input-sm input-small ">
                                                <option value="fixed" selected="selected">Fixed</option>
                                                <option value="default">Default</option>
                                            </select>
                                        </li>
                                        <li class="theme-option layout-setting"><span>Sidebar Menu </span>
                                            <select class="sidebar-menu-option form-control input-inline input-sm input-small ">
                                                <option value="accordion" selected="selected">Accordion</option>
                                                <option value="hover">Hover</option>
                                            </select>
                                        </li>
                                        <li class="theme-option layout-setting"><span>Footer</span>
                                            <select class="page-footer-option form-control input-inline input-sm input-small ">
                                                <option value="fixed">Fixed</option>
                                                <option value="default" selected="selected">Default</option>
                                            </select>
                                        </li>
									</ul>
									<h3 class="list-heading">Account Settings</h3>
									<ul class="list-items borderless theme-options">
                                        <li>Show me Online
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="success" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Status visible to all
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="info" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Everyone will see my stuff
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="danger" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Auto Sumbit Issues
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="warning" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Save History
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="success" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
									</ul>
                                    <h3 class="list-heading">General Settings</h3>
                                    <ul class="list-items borderless">
                                        <li>Enable Notifications
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="info" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Enable SMS Alerts
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="danger" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Location
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="warning" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Show Offline Users
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="success" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                    </ul>
	                        	</div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- end chat sidebar -->
        </div>
        <!-- end page container -->
        <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner">
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="../web/js/jquery.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
    <!-- bootstrap -->
    <script src="../web/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-wizard/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-timepicker/js/bootstrap-timepicker-init.js" type="text/javascript" charset="UTF-8"></script>
    
	<!-- dropzone -->
    <script src="../web/js/dropzone/dropzone.js" type="text/javascript"></script>
    <script src="../web/js/dropzone/dropzone-call.js" type="text/javascript"></script>
    
    <script src="../web/js/jquery.slimscroll.js"></script>
    <script src="../web/js/app.js" type="text/javascript"></script>
    <script src="../web/js/form-wizard.js" type="text/javascript"></script>
    <script src="../web/js/layout.js" type="text/javascript"></script>    
    
     <!-- end js include path -->

            <style>

               .row {
                  display: -ms-flexbox; 
                  display: flex;
                  -ms-flex-wrap: wrap; 
                  flex-wrap: wrap;
                  margin: 0 -16px;
                }

                .col-25 {
                  -ms-flex: 25%; 
                  flex: 25%;
                }

                .col-50 {
                  -ms-flex: 50%; 
                  flex: 50%;
                }

                .col-75 {
                  -ms-flex: 75%; 
                  flex: 75%;
                }

                .col-25,
                .col-50,
                .col-75 {
                  padding: 0 16px;
                }

                .container2 {
                  background-color: #f2f2f2;
                  padding-left: 20%;
                  border: 1px solid lightgrey;
                  border-radius: 3px;
                }

                input, select, textarea {
                  /*[type=text]*/
                  width: 70%;
                  margin-bottom: 20px;
                  padding: 12px;
                  border: 1px solid #ccc;
                  border-radius: 3px;
                }

                label {
                  margin-bottom: 10px;
                  display: block;
                }

                .icon-container {
                  margin-bottom: 20px;
                  padding: 7px 0;
                  font-size: 24px;
                }

                
                .btn2 {
                  background-color: #4CAF50;
                  color: white;
                  padding: 12px;
                  margin: 10px 0;
                  border: none;
                  width: 100%;
                  border-radius: 3px;
                  cursor: pointer;
                  font-size: 17px;
                }

                .btn2:hover {
                  background-color: #45a049;
                }

                a {
                  color: #2196F3;
                }

                hr {
                  border: 1px solid lightgrey;
                }

                span.price {
                  float: right;
                  color: grey;
                }

                /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
                @media (max-width: 800px) {
                  .row {
                    flex-direction: column-reverse;
                  }
                  .col-25 {
                    margin-bottom: 20px;
                  }
                }
            </style>


     <!-- ==================== -->
</body>
</html>