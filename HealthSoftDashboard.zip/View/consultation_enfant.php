<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<head>

    <?php include('../include/headhtml.php'); ?>
    
</head>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md">
    <div class="page-wrapper">
        <!-- start header -->
        <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
                <!-- logo start -->
                <div class="page-logo">
                    <a href="index.html">
                        <img src="img/logo.png" alt="logo" class="logo-default" /> </a>
                    <div class="menu-toggler sidebar-toggler">
                        <span></span>
                    </div>
                </div>
                <!-- logo end -->
                 <form class="search-form-opened" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search..." name="query">
                        <span class="input-group-btn">
                                <a href="javascript:;" class="btn submit">
                                    <i class="icon-magnifier"></i>
                                </a>
                            </span>
                    </div>
                </form>
                <!-- start mobile menu -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
               <!-- end mobile menu -->
                <!-- start header menu -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                    	<!-- start language menu -->
                        <li class="dropdown language-switch">
                            <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false"> <img src="img/flags/gb.png" class="position-left" alt=""> English <span class="fa fa-angle-down"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li>
                                    <a class="deutsch"><img src="img/flags/de.png" alt=""> Deutsch</a>
                                </li>
                                <li>
                                    <a class="ukrainian"><img src="img/flags/ua.png" alt=""> Українська</a>
                                </li>
                                <li>
                                    <a class="english"><img src="img/flags/gb.png" alt=""> English</a>
                                </li>
                                <li>
                                    <a class="espana"><img src="img/flags/es.png" alt=""> España</a>
                                </li>
                                <li>
                                    <a class="russian"><img src="img/flags/ru.png" alt=""> Русский</a>
                                </li>
                            </ul>
                        </li>
                        <!-- end language menu -->
                        <!-- start notification dropdown -->
                        <li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                <i class="fa fa-bell-o"></i>
                                <span class="badge orange-bgcolor"> 6 </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="external">
                                    <h3><span class="bold">Notifications</span></h3>
                                    <span class="notification-label purple-bgcolor">New 6</span>
                                </li>
                                <li>
                                    <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                                        <li>
                                            <a href="javascript:;">
                                                <span class="time">just now</span>
                                                <span class="details">
                                                <span class="notification-icon circle green-bgcolor"><i class="fa fa-check"></i></span> Congratulations!. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <span class="time">3 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle purple-bgcolor"><i class="fa fa-user o"></i></span>
                                                <b>John Micle </b>is now following you. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <span class="time">7 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle blue-bgcolor"><i class="fa fa-comments-o"></i></span>
                                                <b>Sneha Jogi </b>sent you a message. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <span class="time">12 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle pink"><i class="fa fa-heart"></i></span>
                                                <b>Ravi Patel </b>like your photo. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <span class="time">15 mins</span>
                                                <span class="details">
                                                <span class="notification-icon circle yellow"><i class="fa fa-warning"></i></span> Warning! </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <span class="time">10 hrs</span>
                                                <span class="details">
                                                <span class="notification-icon circle red"><i class="fa fa-times"></i></span> Application error. </span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="dropdown-menu-footer">
                                        <a href="javascript:void(0)"> All notifications </a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <!-- end notification dropdown -->
                        <!-- start message dropdown -->
 						<li class="dropdown dropdown-extended dropdown-inbox" id="header_inbox_bar">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                <i class="fa fa-envelope-o"></i>
                                <span class="badge cyan-bgcolor"> 2 </span>
                            </a>
                            <ul class="dropdown-menu">
                                <li class="external">
                                    <h3><span class="bold">Messages</span></h3>
                                    <span class="notification-label cyan-bgcolor">New 2</span>
                                </li>
                                <li>
                                    <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                                        <li>
                                            <a href="#">
                                                <span class="photo">
                                                	<img src="img/doc/doc2.svg" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                	<span class="from"> Sarah Smith </span>
                                                	<span class="time">Just Now </span>
                                                </span>
                                                <span class="message"> Jatin I found you on LinkedIn... </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <span class="photo">
                                                	<img src="img/doc/doc3.svg" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                	<span class="from"> John Deo </span>
                                                	<span class="time">16 mins </span>
                                                </span>
                                                <span class="message"> Fwd: Important Notice Regarding Your Domain Name... </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <span class="photo">
                                                	<img src="img/doc/doc1.svg" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                	<span class="from"> Rajesh </span>
                                                	<span class="time">2 hrs </span>
                                                </span>
                                                <span class="message"> pls take a print of attachments. </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <span class="photo">
                                                	<img src="img/doc/doc8.svg" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                	<span class="from"> Lina Smith </span>
                                                	<span class="time">40 mins </span>
                                                </span>
                                                <span class="message"> Apply for Ortho Surgeon </span>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#">
                                                <span class="photo">
                                                	<img src="img/doc/doc5.svg" class="img-circle" alt=""> </span>
                                                <span class="subject">
                                                	<span class="from"> Jacob Ryan </span>
                                                	<span class="time">46 mins </span>
                                                </span>
                                                <span class="message"> Request for leave application. </span>
                                            </a>
                                        </li>
                                    </ul>
                                    <div class="dropdown-menu-footer">
                                        <a href="#"> All Messages </a>
                                    </div>
                                </li>
                            </ul>
                        </li>
                        <!-- end message dropdown -->
 						<!-- start manage user dropdown -->
 						<li class="dropdown dropdown-user">
                            <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                <img alt="" class="img-circle " src="img/dp.svg" />
                                <span class="username username-hide-on-mobile"> Bansi </span>
                                <i class="fa fa-angle-down"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-default">
                                <li>
                                    <a href="user_profile.html">
                                        <i class="icon-user"></i> Profile </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-settings"></i> Settings
                                    </a>
                                </li>
                                <li>
                                    <a href="#">
                                        <i class="icon-directions"></i> Help
                                    </a>
                                </li>
                                <li class="divider"> </li>
                                <li>
                                    <a href="lock_screen.html">
                                        <i class="icon-lock"></i> Lock
                                    </a>
                                </li>
                                <li>
                                    <a href="login.html">
                                        <i class="icon-logout"></i> Log Out </a>
                                </li>
                            </ul>
                        </li>
                        <!-- end manage user dropdown -->
 						<li class="dropdown dropdown-quick-sidebar-toggler">
                            <a href="javascript:;" class="dropdown-toggle">
                                <i class="icon-logout"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end header -->
        <div class="clearfix"> </div>
        <!-- start page container -->
        <div class="page-container">
 			<!-- start sidebar menu -->
            <?php include('../include/boxSideMenu.php'); ?>
            <!-- end sidebar menu -->
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Add Consultation</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li><a class="parent-item" href="">Consultations</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Add Consultation</li>
                            </ol>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="card card-topline-aqua" id="form_wizard_1">
                                <div class="card-head">
                                </div>
                                <div class="card-body" id="bar-parent">

                                <div class="container2">

                                <form class="form-horizontal" action="../Manager/TraitementConsultationEnfant.php" id="submit_form" method="POST">
                                        <div class="form-wizard">
                                           <!-- ============== -->
                                        
                                            <div class="row">
                                              <div class="col-50">

                                                <h3>Consultation Enfant</h3>

                                                <label for="fname"><i class="fa fa-user"></i> Code national du patient</label>
                                                <input type="text" id="fname" name="code_national" value="" >

                                                 <?php include('../genuis_connection_login/generate.php'); ?>

                                                <label for="fname"><i class="fa fa-user"></i> Code du system </label>
                                                <input type="text" id="fname" readonly name="code_attrib" value="<?php echo $generatedCode; ?>" >                                                

                                                <label for="fname"><i class="fa fa-user"></i> Nom </label>
                                                <input type="text" id="fname" name="nom" placeholder="Kendly" value="" >

                                                <label for="email"><i class="fa fa-envelope"></i> Prenom</label>
                                                <input type="text" id="email" name="prenom" value="">

                                                <label for="adr"><i class="fa fa-address-card-o"></i> Age </label>
                                                <input type="text" id="adr" name="age"  value="">   

                                                <label > Sexe </label>
                                                        <select name="sexe" >
                                                          <option selected>M</option>
                                                          <option >F</option>                                
                                                        </select>  

                                                <label > Refere(e) </label>
                                                        <select name="refere" >
                                                         <option>OUI</option>
                                                         <option>NON</option>
                                                        </select>              

                                                <label > Groupe Sanguin </label>
                                                        <select name="groupe_sanguin" >
                                                          <option>A+</option>
                                                          <option>A-</option>
                                                          <option>B+</option>
                                                          <option>B-</option>   
                                                          <option>O+</option>
                                                          <option>O-</option>   
                                                          <option>AB+</option>
                                                          <option>AB-</option>  
                                                          <option>Inconnu</option>                    
                                                        </select>
                                                

                                                 <label > Electrophorèse de l'emoglobine </label>
                                                        <select name="electrophorese" >
                                                         <option>AB</option>
                                                         <option>SS</option>
                                                         <option>SC</option>
                                                         <option>AA</option>
                                                         <option>Inconnu</option>                                        
                                                        </select>


                                                <label > Autre? precisez</label>
                                                    <input type="text" name="autres_1">                             

                                                        <label > Scolarisé </label>
                                                        <select name="scolarise" >
                                                         <option>OUI</option>
                                                         <option>NON</option>
                                                        </select>

                                                         <label > Si OUI precisez </label>                                  
                                                         <input type="text" name="scolarise_2">

                                                         <label > Poids de Naissance </label>                                   
                                                         <input type="text" name="poids_naissance">

                                                        
                                                
                                                <h3>Antecedent HEREDO-COLLATEREAUX</h3>

                                               
                                                        <label > Asthme</label>
                                                        <select name="asthme_fam" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                     
                                                
                                                  
                                                    <label > Cancer </label>
                                                        <select name="cancer_fam" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                        <label > Precisez </label>
                                                        <input type="text" id="zip" name="cancer_fam_2" >
                                                 

                                             
                                                     <label > Cardiopathie </label>
                                                        <select name="cardiopathie_fam" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                 

                                                     <label > Diabète </label>
                                                        <select name="diabete_fam" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                

                                                     <label > Epilepsie </label>
                                                        <select name="epilepsie_fam" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                  
                                                     <label > HTA </label>
                                                        <select name="hta_fam" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                  
                                                     <label > Turbeculose </label>
                                                        <select name="turberculose_fam" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                

                                                  <h3>Antecedents personnels/ Habitudes</h3>

                                               
                                                     <label > Accident cerebro-vasculaire </label>                               
                                                        <select name="accident_cerebro_vasculaire" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select>
                                                 
                                                    <label > Allergies </label>                              
                                                        <select name="allergies_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 
                                                        <label > Precisez </label>
                                                        <input type="text"  name="allergies_pers_2" > 

                                                    <label > Asthme </label>                              
                                                        <select name="asthme_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 
                                                                                
                                                 
                                                    <label > Cancer </label>                             
                                                        <select name="cancer_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 
                                                        <label > Precisez </label>
                                                        <input type="text"  name="cancer_pers_2" >                            
                                                
                                                    <label > Chirurgies / Trauma </label>                            
                                                        <select name="chirurgie_trauma" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 
                                                        <label > Precisez </label>
                                                        <input type="text"  name="chirurgie_trauma_2" >                            
                                                  
                                                    <label > Cardiopathie </label>                               
                                                        <select name="cardiopathie_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select>                                                         
                                                  
                                                    <label > Prematuré </label>                              
                                                        <select name="premature" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select>                                                         
                                                  
                                                        <label > RAA </label>                            
                                                        <select name="raa" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                                      
                                                        </select>                     
                                                                                                                    

                                                        <label > Diabète </label>                            
                                                        <select name="diabete_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                                          
                                                        </select>                                                               

                                                        <label > Epilepsie </label>                              
                                                        <select name="epilepsie_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                                          
                                                        </select>                                                                                     
                                                  
                                                        <label > Hemoglobinopathie </label>                              
                                                        <select name="hemoglobinopathie" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 
                                                        <label > Precisez </label>
                                                        <input type="text"  name="hemoglobinopathie_2" >                            
                                                 
                                                        <label > HTA </label>                            
                                                        <select name="hta_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                   
                                                        </select>                                                                                     
                                               
                                                        <label > IST </label>                            
                                                        <select name="ist_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 
                                                        <label > Precisez </label>
                                                        <input type="text"  name="ist_pers_2" >                            
                                                 
                                                        <label > Malnutrition / Perte de poids </label>                              
                                                        <select name="malnutrition_perte_poids" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                                          
                                                        </select>                                                                                     
                                                   
                                                        <label >  Malaria <= 1 mois </label>                             
                                                        <select name="malaria_moins_1_mois" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                                          
                                                        </select>                                                                                     
                                                   
                                                        <label >  Malaria >= 1 mois </label>                             
                                                        <select name="malaria_plus_1_mois" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                                          
                                                        </select>                                                                                     
                                                   
                                                        <label > Rougeole </label>                               
                                                        <select name="rougeole" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 

                                                         <label > Turbeculose </label>
                                                        <select name="turberculose_pers" >
                                                          <option selected>Mere</option>
                                                          <option value="1">Pere</option>
                                                          <option value="2">Fere</option>
                                                          <option value="3">Soeur</option>
                                                        </select>
                                                        
                                                        <label > Varicelle </label>                              
                                                        <select name="varicelle" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                                          
                                                        </select>                                                                                     
                                                 
                                                        <label > Malf. Congenitales </label>                             
                                                        <select name="malf_congenitales" >
                                                          <option selected>OUI</option>
                                                          <option value="1">NON</option>                                  
                                                        </select> 
                                                        <label > Precisez </label>
                                                        <input type="text"  name="malf_congenitales_2" >                            
                                                   
                                                        <label > Diphtérie </label>                              
                                                        <select name="diphterie_pers" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                                          
                                                        </select>   

                                                        <label > Autre Precisez </label>
                                                        <input type="text"  name="autres_2" >                                                                                 
                                                   
                                                        <label > Medicaments actuel </label>                             
                                                        <textarea name="medicaments_actuels" >
                                                            
                                                        </textarea> 

                                                        <label > Hospitalisation Antérieure </label>                             
                                                        <select name="hospitalisation_anterieure" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>    
                                                          <option value="1">Inconnu</option>                                                      
                                                        </select>

                                                        <label > Si Oui : la cause </label>                              
                                                        <textarea name="hospitalisation_anterieure_2">
                                                            
                                                        </textarea>

                                                        <h3> Histoire Alimentaire </h3>

                                                        <label >  Allaitement maternel exclusif </label>                       
                                                        <select name="allaitement_mat_exclusif" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                              
                                                        </select> 

                                                        <label > Si Oui : duree en mois </label> 
                                                        <input type="text" name="allaitement_mat_exclusif_2">

                                                        <label >  Preparation pour nourissons (LM) </label>                              
                                                        <select name="preparation_nourrissons" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                              
                                                        </select> 

                                                        <label > Si Oui : precisez le lait </label> 
                                                        <input type="text" name="preparation_nourrissons">

                                                        <label >  Alimentation mixte</label>                             
                                                        <select name="alimentation_mixte" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                      
                                                        </select> 

                                                        <label >  Diversification Alimentaire </label>                         
                                                        <select name="diversification_alimentaire" >
                                                          <option selected>OUI</option>
                                                          <option value="1">Non</option>                                              
                                                        </select> 

                                                        <label > Si Oui : age en mois </label> 
                                                        <input type="text" name="diversification_alimentaire_2">

                                                        <h3> Vaccins </h3>

                                                        <label > SBCG </label> 
                                                        <input type="text" name="vaccin_bcg">

                                                        <label > POLIO </label> 
                                                        <input type="text" name="vaccin_polio">

                                                        <label > DTPER </label> 
                                                        <input type="text" name="vaccin_dtper">

                                                        <label > ROUGEOLE </label> 
                                                        <input type="text" name="vaccin_rougeole">

                                                        <label > RR </label> 
                                                        <input type="text" name="vaccin_rr">

                                                        <label > DT </label> 
                                                        <input type="text" name="vaccin_dt">

                                                        <label > Hepatite B </label> 
                                                        <input type="text" name="vaccin_hepatite_b">

                                                        <label > Act Hib </label> 
                                                        <input type="text" name="vaccin_act_hib">

                                                        <label > Autre </label> 
                                                        <textarea name="vaccin_autre">
                                                            
                                                        </textarea>

                                                    </div>

                                                </div>   
                                            
                                        </div>

                                        <input type="submit" name="" class="btn btn-outline green-bgcolor button-next" >
                                </form>
                            </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end page content -->
            <!-- start chat sidebar -->
            <div class="chat-sidebar-container" data-close-on-body-click="false">
                <div class="chat-sidebar">
                    <ul class="nav nav-tabs">
                        <li class="active">
                            <a href="javascript:;" data-target="#quick_sidebar_tab_1" data-toggle="tab"> Users
                                    <span class="badge badge-danger">4</span>
                                </a>
                        </li>
                        <li>
                            <a href="javascript:;" data-target="#quick_sidebar_tab_3" data-toggle="tab"> <i class="icon-settings"></i> Settings
                            </a>
                        </li>
                    </ul>
                    
                    <div class="tab-content">
                        <!-- Start Doctor Chat --> 
 						<div class="tab-pane active chat-sidebar-chat" id="quick_sidebar_tab_1">
                        	<div class="chat-sidebar-list">
	                            <div class="chat-sidebar-chat-users slimscroll-style" data-rail-color="#ddd" data-wrapper-class="chat-sidebar-list">
	                                <h3 class="list-heading">Online</h3>
	                                <ul class="media-list list-items">
	                                    <li class="media"><img class="media-object" src="img/doc/doc3.svg" width="35" height="35" alt="...">
	                                        <i class="online dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">John Deo</h4>
	                                            <div class="media-heading-sub">Spine Surgeon</div>
	                                        </div>
	                                    </li>
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-success">5</span>
	                                        </div> <img class="media-object" src="img/doc/doc1.svg" width="35" height="35" alt="...">
	                                        <i class="busy dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Rajesh</h4>
	                                            <div class="media-heading-sub">Director</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc5.svg" width="35" height="35" alt="...">
	                                        <i class="away dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Jacob Ryan</h4>
	                                            <div class="media-heading-sub">Ortho Surgeon</div>
	                                        </div>
	                                    </li>
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-danger">8</span>
	                                        </div> <img class="media-object" src="img/doc/doc4.svg" width="35" height="35" alt="...">
	                                        <i class="online dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Kehn Anderson</h4>
	                                            <div class="media-heading-sub">CEO</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc2.svg" width="35" height="35" alt="...">
	                                        <i class="busy dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Sarah Smith</h4>
	                                            <div class="media-heading-sub">Anaesthetics</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc7.svg" width="35" height="35" alt="...">
	                                        <i class="online dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Vlad Cardella</h4>
	                                            <div class="media-heading-sub">Cardiologist</div>
	                                        </div>
	                                    </li>
	                                </ul>
	                                <h3 class="list-heading">Offline</h3>
	                                <ul class="media-list list-items">
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-warning">4</span>
	                                        </div> <img class="media-object" src="img/doc/doc6.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Jennifer Maklen</h4>
	                                            <div class="media-heading-sub">Nurse</div>
	                                            <div class="media-heading-small">Last seen 01:20 AM</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc8.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Lina Smith</h4>
	                                            <div class="media-heading-sub">Ortho Surgeon</div>
	                                            <div class="media-heading-small">Last seen 11:14 PM</div>
	                                        </div>
	                                    </li>
	                                    <li class="media">
	                                        <div class="media-status">
	                                            <span class="badge badge-success">9</span>
	                                        </div> <img class="media-object" src="img/doc/doc9.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Jeff Adam</h4>
	                                            <div class="media-heading-sub">Compounder</div>
	                                            <div class="media-heading-small">Last seen 3:31 PM</div>
	                                        </div>
	                                    </li>
	                                    <li class="media"><img class="media-object" src="img/doc/doc10.svg" width="35" height="35" alt="...">
	                                        <i class="offline dot"></i>
	                                        <div class="media-body">
	                                            <h4 class="media-heading">Anjelina Cardella</h4>
	                                            <div class="media-heading-sub">Physiotherapist</div>
	                                            <div class="media-heading-small">Last seen 7:45 PM</div>
	                                        </div>
	                                    </li>
	                                </ul>
	                            </div>
                            </div>
                            <div class="chat-sidebar-item">
                                <div class="chat-sidebar-chat-user">
                                    <div class="page-quick-sidemenu">
                                        <a href="javascript:;" class="chat-sidebar-back-to-list">
                                            <i class="fa fa-angle-double-left"></i>Back
                                        </a>
                                    </div>
                                    <div class="chat-sidebar-chat-user-messages">
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:10</span>
                                                <span class="body-out"> could you send me menu icons ? </span>
                                            </div>
                                        </div>
                                        <div class="post in">
                                            <img class="avatar" alt="" src="img/doc/doc5.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:10</span>
                                                <span class="body"> please give me 10 minutes. </span>
                                            </div>
                                        </div>
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:11</span>
                                                <span class="body-out"> ok fine :) </span>
                                            </div>
                                        </div>
                                        <div class="post in">
                                            <img class="avatar" alt="" src="img/doc/doc5.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:22</span>
                                                <span class="body">Sorry for
													the delay. i sent mail to you. let me know if it is ok or not.</span>
                                            </div>
                                        </div>
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:26</span>
                                                <span class="body-out"> it is perfect! :) </span>
                                            </div>
                                        </div>
                                        <div class="post out">
                                            <img class="avatar" alt="" src="img/dp.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Bansi Patel</a> <span class="datetime">9:26</span>
                                                <span class="body-out"> Great! Thanks. </span>
                                            </div>
                                        </div>
                                        <div class="post in">
                                            <img class="avatar" alt="" src="img/doc/doc5.svg" />
                                            <div class="message">
                                                <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:27</span>
                                                <span class="body"> it is my pleasure :) </span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="chat-sidebar-chat-user-form">
                                        <div class="input-group">
                                            <input type="text" class="form-control" placeholder="Type a message here...">
                                            <div class="input-group-btn">
                                                <button type="button" class="btn green-bgcolor">
                                                    <i class="fa fa-arrow-right"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Doctor Chat --> 
 						<!-- Start Setting Panel --> 
 						<div class="tab-pane chat-sidebar-settings" id="quick_sidebar_tab_3">
                            <div class="chat-sidebar-settings-list">
                                <h3 class="list-heading">Layout Settings</h3>
	                            <div class="chatpane inner-content ">
	                            	<ul class="list-items borderless theme-options">
                                        <li class="theme-option layout-setting"><span>Sidebar
												Position </span>
                                            <select class="sidebar-pos-option form-control input-inline input-sm input-small ">
                                                <option value="left" selected="selected">Left</option>
                                                <option value="right">Right</option>
                                            </select>
                                        </li>
                                        <li class="theme-option layout-setting"><span>Header</span>
                                            <select class="page-header-option form-control input-inline input-sm input-small ">
                                                <option value="fixed" selected="selected">Fixed</option>
                                                <option value="default">Default</option>
                                            </select>
                                        </li>
                                        <li class="theme-option layout-setting"><span>Sidebar Menu </span>
                                            <select class="sidebar-menu-option form-control input-inline input-sm input-small ">
                                                <option value="accordion" selected="selected">Accordion</option>
                                                <option value="hover">Hover</option>
                                            </select>
                                        </li>
                                        <li class="theme-option layout-setting"><span>Footer</span>
                                            <select class="page-footer-option form-control input-inline input-sm input-small ">
                                                <option value="fixed">Fixed</option>
                                                <option value="default" selected="selected">Default</option>
                                            </select>
                                        </li>
									</ul>
									<h3 class="list-heading">Account Settings</h3>
									<ul class="list-items borderless theme-options">
                                        <li>Show me Online
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="success" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Status visible to all
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="info" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Everyone will see my stuff
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="danger" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Auto Sumbit Issues
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="warning" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Save History
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="success" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
									</ul>
                                    <h3 class="list-heading">General Settings</h3>
                                    <ul class="list-items borderless">
                                        <li>Enable Notifications
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="info" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Enable SMS Alerts
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="danger" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Location
                                            <input type="checkbox" class="make-switch" data-size="small" data-on-color="warning" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                        <li>Show Offline Users
                                            <input type="checkbox" class="make-switch" checked data-size="small" data-on-color="success" data-on-text="ON" data-off-color="default" data-off-text="OFF">
                                        </li>
                                    </ul>
	                        	</div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <!-- end chat sidebar -->
        </div>
        <!-- end page container -->
        <!-- start footer -->
        <div class="page-footer">
            <div class="page-footer-inner">
            </div>
            <div class="scroll-to-top">
                <i class="icon-arrow-up"></i>
            </div>
        </div>
        <!-- end footer -->
    </div>
    <!-- start js include path -->
    <script src="../web/js/jquery.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery.blockui.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery-validation/js/jquery.validate.min.js" type="text/javascript"></script>
    <script src="../web/js/jquery-validation/js/additional-methods.min.js" type="text/javascript"></script>
    <!-- bootstrap -->
    <script src="../web/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-wizard/jquery.bootstrap.wizard.min.js" type="text/javascript"></script>
    <script src="../web/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-datetimepicker/js/bootstrap-datetimepicker-init.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript" charset="UTF-8"></script>
    <script src="../web/js/bootstrap-timepicker/js/bootstrap-timepicker-init.js" type="text/javascript" charset="UTF-8"></script>
    
	<!-- dropzone -->
    <script src="../web/js/dropzone/dropzone.js" type="text/javascript"></script>
    <script src="../web/js/dropzone/dropzone-call.js" type="text/javascript"></script>
    
    <script src="../web/js/jquery.slimscroll.js"></script>
    <script src="../web/js/app.js" type="text/javascript"></script>
    <script src="../web/js/form-wizard.js" type="text/javascript"></script>
    <script src="../web/js/layout.js" type="text/javascript"></script>    
    
     <!-- end js include path -->

            <style>

               .row {
                  display: -ms-flexbox; 
                  display: flex;
                  -ms-flex-wrap: wrap; 
                  flex-wrap: wrap;
                  margin: 0 -16px;
                }

                .col-25 {
                  -ms-flex: 25%; 
                  flex: 25%;
                }

                .col-50 {
                  -ms-flex: 50%; 
                  flex: 50%;
                }

                .col-75 {
                  -ms-flex: 75%; 
                  flex: 75%;
                }

                .col-25,
                .col-50,
                .col-75 {
                  padding: 0 16px;
                }

                .container2 {
                  background-color: #f2f2f2;
                  padding-left: 20%;
                  border: 1px solid lightgrey;
                  border-radius: 3px;
                }

                input, select, textarea {
                  /*[type=text]*/
                  width: 70%;
                  margin-bottom: 20px;
                  padding: 12px;
                  border: 1px solid #ccc;
                  border-radius: 3px;
                }

                label {
                  margin-bottom: 10px;
                  display: block;
                }

                .icon-container {
                  margin-bottom: 20px;
                  padding: 7px 0;
                  font-size: 24px;
                }

                
                .btn2 {
                  background-color: #4CAF50;
                  color: white;
                  padding: 12px;
                  margin: 10px 0;
                  border: none;
                  width: 100%;
                  border-radius: 3px;
                  cursor: pointer;
                  font-size: 17px;
                }

                .btn2:hover {
                  background-color: #45a049;
                }

                a {
                  color: #2196F3;
                }

                hr {
                  border: 1px solid lightgrey;
                }

                span.price {
                  float: right;
                  color: grey;
                }

                /* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
                @media (max-width: 800px) {
                  .row {
                    flex-direction: column-reverse;
                  }
                  .col-25 {
                    margin-bottom: 20px;
                  }
                }
            </style>


     <!-- ==================== -->
</body>
</html>