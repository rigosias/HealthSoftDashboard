<?php
trait MonTrait

{

  public function calculateAgePatient()

  {

    $today = new DateTime();
	$birthdate = new DateTime("1973-04-18 09:48:00");
	$interval = $today->diff($birthdate);
	echo $interval->format('%y ans');

  }

}
	
	//$dateDeNaissancePatient=1;
	//echo $dateDeNaissancePatient2='"'.$dateDeNaissancePatient.'"'

?>