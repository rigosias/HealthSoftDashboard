<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<!-- BEGIN HEAD -->
<?php include('../include/headhtml.php'); ?>
<!-- END HEAD -->
<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md page-container-bg-solid page-content-white">
    <div class="page-wrapper">
        <!-- start header -->
         <div class="page-header navbar navbar-fixed-top">
            <div class="page-header-inner ">
                <!-- logo start -->
                 <div class="page-logo">
                    <a href="../home/Dashboard.php" id="centerHopitalName">                
                            <?php  echo $_SESSION['HOPITAL_NAME']; ?>                      
                    </a>
                    <style type="text/css">
                        #centerHopitalName {
                            margin-top: 15px;
                            text-align: center; 
                            font-size: 18px;
                            font-weight: bold; 
                            color: white;                        
                        }
                    </style>
                    <div class="menu-toggler sidebar-toggler">
                        <span></span>
                    </div>
                </div>
                <!-- logo end -->
                 <form class="search-form-opened" action="#" method="GET">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search..." name="query">
                        <span class="input-group-btn">
                                <a href="javascript:;" class="btn submit">
                                    <i class="icon-magnifier"></i>
                                </a>
                            </span>
                    </div>
                </form>
                <!-- start mobile menu -->
                <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                    <span></span>
                </a>
               <!-- end mobile menu -->
                <!-- start header menu -->
                <div class="top-menu">
                    <ul class="nav navbar-nav pull-right">
                    	
						<!-- start language menu -->
                        <?php include('../include/langueMenu.php'); ?>
                        <!-- end language menu -->
                        
						<!-- start notification dropdown -->
						<?php include('../include/dropDownNotification.php'); ?>
                        <!-- end notification dropdown -->
                        
						<!-- start message dropdown -->
 						<?php include('../include/dropdownMessage.php'); ?>
                        <!-- end message dropdown -->
 						
						<!-- start manage user dropdown -->
 						<?php include('../include/userDropdown.php'); ?>
                        <!-- end manage user dropdown -->
 						<li class="dropdown dropdown-quick-sidebar-toggler">
                            <a href="javascript:;" class="dropdown-toggle">
                                <i class="icon-logout"></i>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- end header -->
        <div class="clearfix"> </div>
        <!-- start page container -->
        <div class="page-container">
 			<!-- start sidebar menu -->
			<?php include('../include/boxSideMenu.php'); ?>
 			            <!-- end sidebar menu --> 
			<!-- start page content -->
            <div class="page-content-wrapper">
                <div class="page-content">
                    <div class="page-bar">
                        <div class="page-title-breadcrumb">
                            <div class=" pull-left">
                                <div class="page-title">Patient Profile</div>
                            </div>
                            <ol class="breadcrumb page-breadcrumb pull-right">
                                <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="index.html">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li><a class="parent-item" href="">Patients</a>&nbsp;<i class="fa fa-angle-right"></i>
                                </li>
                                <li class="active">Patient Profile</li>
                            </ol>
                        </div>
                    </div>
                    <div class="row">
	                    <div class="col-md-4 col-xs-12">
	                        <div class="white-box">
								<div class=" cardbox patient-profile">
									<img src="../web/img/patient1.jpg" class="img-responsive" alt="">
								</div>
								<div class="cardbox">
			                    <div class="header">
			                        <h2 class="font-bold">About Patient</h2>
			                    </div>
				                    <div class="body">
				                        <div class="user-btm-box">
				                                <!-- .row -->
				                                <div class="row text-center m-t-10">
				                                    <div class="col-lg-6 col-md-12 col-sm-6 col-xs-12 b-r"><strong>Name</strong>
				                                        <p><?php echo $_GET['nom'].' / '.$_GET['prenom']; ?></p>
				                                    </div>
				                                    <div class="col-lg-6 col-md-12 col-sm-6 col-xs-12"><strong>Occupation</strong>
				                                        <p>Engineer</p>
				                                    </div>
				                                </div>
				                                <!-- /.row -->
				                                <hr>
				                                <!-- .row -->
				                                <div class="row text-center m-t-10">
				                                    <div class="col-lg-6 col-md-12 col-sm-6 col-xs-12 b-r"><strong>Email ID</strong>
				                                        <p>pankaj@gmail.com</p>
				                                    </div>
				                                    <div class="col-lg-6 col-md-12 col-sm-6 col-xs-12"><strong>Phone</strong>
				                                        <p><?php echo $_GET['tel']; ?></p>
				                                    </div>
				                                </div>
				                                <!-- /.row -->
				                                <hr>
				                                <!-- .row -->
				                                <div class="row text-center m-t-10">
				                                    <div class="col-md-12"><strong>Address</strong>
				                                        <p><?php echo $_GET['adrs']; ?></p>
				                                    </div>
				                                </div>
				                            </div>
				                    	</div>
			                		</div>
	                        	</div>
	                   	 </div>
	                    <div class="col-md-8 col-xs-12">
                            <div class="cardbox">
			                    <div class="body"> 
                                    <div class="mypost-list">
                                        <div class="post-box">
                                            <p>It is also used to identify any abnormal tissue in the uterine cavity, such as uterine fibroids, endometrial polyps, scar tissue, or retained pregnancy tissue, the presence of which may be suggested by history or previous tests such as a hysterosalpingogram (x-ray of the uterus and tubes). This procedure is done in the office here at IVF New England, and is done by one of the physicians.  </p>
                                            <p>Approximately an hour before the exam we suggest that you take Ibuprofen 600 mg (Motrin/Advil) or a similar medication to minimize some mild to moderate cramping that you may experience during the procedure. </p>
                                        </div>
                                        <hr>
                                        <div class="post-box">
                                            <h4 class="font-bold">General Report</h4>                                        
                                            <hr>
                                            <h5>Heart Beat <span class="pull-right">90</span></h5>
				                            <div class="progress">
				                                <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%"> <span class="sr-only">40% Complete (success)</span> </div>
				                            </div>
				                            <h5>Blood Pressure<span class="pull-right">93</span></h5>
				                            <div class="progress">
				                                <div class="progress-bar progress-bar-warning progress-bar-striped active" role="progressbar" aria-valuenow="90" aria-valuemin="0" aria-valuemax="100" style="width:90%;"> <span class="sr-only">50% Complete</span> </div>
				                            </div>
				                            <h5>Sugar<span class="pull-right">55</span></h5>
				                            <div class="progress">
				                                <div class="progress-bar progress-bar-primary progress-bar-striped active" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width:50%;"> <span class="sr-only">50% Complete</span> </div>
				                            </div>
				                            <h5>Haemoglobin<span class="pull-right">78%</span></h5>
				                            <div class="progress">
				                                <div class="progress-bar progress-bar-danger progress-bar-striped active" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%;"> <span class="sr-only">50% Complete</span> </div>
				                            </div>
                                        </div>
                                        </div>
                                        <hr>
                                        <div class="row">
					                        <div class="col-md-12">
					                            <div class="row">
					                                <div class="col-md-12">
					                                    <div class="card card-topline-purple">
					                                        <div class="card-head">
					                                            <header>Past Visit History</header>
					                                        </div>
					                                        <div class="card-body ">
					                                        	<div class="table-responsive">
					                                            <table class="table table-striped custom-table table-hover">
					                                                <thead>
					                                                    <tr>
					                                                        <th>Date</th>
					                                                        <th>Doctor</th>
					                                                        <th>Treatment</th>
					                                                        <th>Chart</th>
					                                                        <th>Charges($)</th>
					                                                        <th>Action</th>
					                                                    </tr>
					                                                </thead>
					                                                <tbody>
					                                                    <tr>
					                                                        <td>11/05/2017</td>
					                                                        <td>Dr.Rajesh</td>
					                                                        <td>Check up</td>
					                                                        <td><div id="sparkline"></div></td>
					                                                        <td>14$</td>
					                                                        <td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit">
					                                                        	<i class="fa fa-check"></i></a> 
					                                                        	<a href="javascript:void(0)" class="text-inverse" title="Delete" data-toggle="tooltip">
					                                                        	<i class="fa fa-trash"></i></a>
					                                                        </td>
					                                                    </tr>
					                                                    <tr>
					                                                        <td>13/05/2017</td>
					                                                        <td>Dr.Rajesh</td>
					                                                        <td>X-Ray</td>
					                                                        <td><div id="sparkline3"></div></td>
					                                                        <td>16$</td>
					                                                        <td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit">
					                                                        	<i class="fa fa-check"></i></a> 
					                                                        	<a href="javascript:void(0)" class="text-inverse" title="Delete" data-toggle="tooltip">
					                                                        	<i class="fa fa-trash"></i></a>
					                                                        </td>
					                                                    </tr>
					                                                    <tr>
					                                                        <td>13/05/2017</td>
					                                                        <td>Dr.Rajesh</td>
					                                                        <td>Blood Test</td>
					                                                        <td><div id="sparkline1"></div></td>
					                                                        <td>24$</td>
					                                                        <td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit">
					                                                        	<i class="fa fa-check"></i></a> 
					                                                        	<a href="javascript:void(0)" class="text-inverse" title="Delete" data-toggle="tooltip">
					                                                        	<i class="fa fa-trash"></i></a>
					                                                        </td>
					                                                    </tr>
					                                                    <tr>
					                                                        <td>14/05/2017</td>
					                                                        <td>Dr.Rajesh</td>
					                                                        <td>Admit</td>
					                                                        <td><div id="sparkline2"></div></td>
					                                                        <td>14$</td>
					                                                        <td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit">
					                                                        	<i class="fa fa-check"></i></a> 
					                                                        	<a href="javascript:void(0)" class="text-inverse" title="Delete" data-toggle="tooltip">
					                                                        	<i class="fa fa-trash"></i></a>
					                                                        </td>
					                                                    </tr>
					                                                    <tr>
					                                                        <td>15/05/2017</td>
					                                                        <td>Dr.Rajesh</td>
					                                                        <td>Operation</td>
					                                                        <td><div id="sparkline4"></div></td>
					                                                        <td>14$</td>
					                                                        <td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit">
					                                                        	<i class="fa fa-check"></i></a> 
					                                                        	<a href="javascript:void(0)" class="text-inverse" title="Delete" data-toggle="tooltip">
					                                                        	<i class="fa fa-trash"></i></a>
					                                                        </td>
					                                                    </tr>
					                                                    <tr>
					                                                        <td>18/05/2017</td>
					                                                        <td>Dr.Rajesh</td>
					                                                        <td>Discharge</td>
					                                                        <td><div id="sparkline5"></div></td>
					                                                        <td>14$</td>
					                                                        <td><a href="javascript:void(0)" class="" data-toggle="tooltip" title="Edit">
					                                                        	<i class="fa fa-check"></i></a> 
					                                                        	<a href="javascript:void(0)" class="text-inverse" title="Delete" data-toggle="tooltip">
					                                                        	<i class="fa fa-trash"></i></a>
					                                                        </td>
					                                                    </tr>
					                                                </tbody>
					                                            </table>
					                                            </div>
					                                        </div>
					                                    </div>
					                                </div>
					                            </div>
					                        </div>
					                    </div>
                                     <hr>
                                    <h4 class="font-bold">ECG Report</h4>
                                    <div class="demo-container">
										<div id="placeholder" class="demo-placeholder"></div>
									</div>
			                    </div>
			                </div>
	                    </div>
                    </div>
                </div>
                <!-- end page content -->
                <!-- start chat sidebar -->
                <div class="chat-sidebar-container" data-close-on-body-click="false">
                    <div class="chat-sidebar">
                        <ul class="nav nav-tabs">
                            <li class="active">
                                <a href="javascript:;" data-target="#quick_sidebar_tab_1" data-toggle="tab"> Users
                                    <span class="badge badge-danger">4</span>
                                </a>
                            </li>
                            <li>
                                <a href="javascript:;" data-target="#quick_sidebar_tab_3" data-toggle="tab"> <i class="icon-settings"></i> Settings
                                </a>
                            </li>
                        </ul>
                        
                        <div class="tab-content">
                            <!-- Start Doctor Chat --> 
 						<?php include ('../include/boxDocteurChat.php');?>
                         <!-- End Doctor Chat --> 
 						
                <!-- end chat sidebar -->
            </div>
            <!-- end page container -->
            <!-- start footer -->
            <div class="page-footer">
                <div class="page-footer-inner">
                    
                </div>
                <div class="scroll-to-top">
                    <i class="icon-arrow-up"></i>
                </div>
            </div>
            <!-- end footer -->
        </div></div>
        <!-- start js include path -->
        <script src="../web/js/jquery.min.js" type="text/javascript"></script>
        <script src="../web/js/jquery.blockui.min.js" type="text/javascript"></script>
        <script src="../web/js/jquery.sparkline.min.js" type="text/javascript"></script>
        <!-- bootstrap -->
        <script src="../web/js/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="../web/js/bootstrap-switch/js/bootstrap-switch.min.js" type="text/javascript"></script>
        
        <script src="../web/js/jquery.slimscroll.js"></script>
        <script src="../web/js/app.js" type="text/javascript"></script>
        <script src="../web/js/profile.js" type="text/javascript"></script>
        <script src="../web/js/layout.js" type="text/javascript"></script>
        
        
        <script src="../web/js/float/jquery.flot.js" type="text/javascript"></script>
	    <script src="../web/js/float/ecg-data.js" type="text/javascript"></script>
	    <script src="../web/js/float/jquery.flot.resize.min.js" type="text/javascript"></script>
	    <script src="../web/js/sparkline/jquery.sparkline.js" type="text/javascript"></script>
	    <script src="../web/js/sparkline/sparkline-data.js" type="text/javascript"></script>
        <!-- end js include path -->
</body>
</html>