<?php

	
	/**
	* 
	*/
public Class ConsultationEnfant
	{

			$code_natinal;
			$code_attrib ;
			$nom ;
			$prenom	; 
			$refere	 ;
			$scolarite ;
			$electrophorese ;
			$poids_naissance ;
			$asthme_fam ;
			$cancer_fam ;
			$cardiopathie_fam ;
			$diabete_fam ;
			$epilepsie_fam; 
			$hta_fam ;
			$turberculose_fam ;
			$autres_1 ;
			$allergies_pers ;
			$asthme_pers ;
			$cardiopathie_pers ;
			$chirurgie_trauma ;
			$diabete_pers ;
			$diphterie_pers ;
			$epilepsie_pers ;
			$hemoglobinopathie ;
			$hta_pers ;
			$ist_pers ;
			$malaria_moins_1_mois ;
			$malaria_plus_1_mois ;
			$malf_congenitales ;
			$malnutrition_perte_poids ;
			$premature ;
			$raa ;
			$rougeole ;
			$tuberculose_pers ;
			$varicelle ;
			$autres_2;
			$medicaments_actuels ;
			$hospitalisation_anterieure ;
			$allaitement_mat_exclusif ;
			$preparation_nourrissons;
			$alimentation_mixte ;
			$diversification_alimentaire ;
			$vaccin_bcg ;
			$vaccin_polio ;
			$vaccin_dtper ;
			$vaccin_rougeole ;
			$vaccin_rr ;
			$vaccin_dt ;
			$vaccin_hepatite_b ;
			$vaccin_act_hib ;
			$vaccin_autre ;
			$date_consultation;
			
		
		public function __construct(

					$code_natinal,
					$code_attrib ,
					$nom ,
					$prenom	, 
					$refere	 ,
					$scolarite ,
					$electrophorese ,
					$poids_naissance ,
					$asthme_fam ,
					$cancer_fam ,
					$cardiopathie_fam ,
					$diabete_fam ,
					$epilepsie_fam, 
					$hta_fam ,
					$turberculose_fam ,
					$autres_1 ,
					$allergies_pers ,
					$asthme_pers ,
					$cardiopathie_pers ,
					$chirurgie_trauma ,
					$diabete_pers ,
					$diphterie_pers ,
					$epilepsie_pers ,
					$hemoglobinopathie ,
					$hta_pers ,
					$ist_pers ,
					$malaria_moins_1_mois ,
					$malaria_plus_1_mois ,
					$malf_congenitales ,
					$malnutrition_perte_poids ,
					$premature ,
					$raa ,
					$rougeole ,
					$tuberculose_pers ,
					$varicelle ,
					$autres_2,
					$medicaments_actuels ,
					$hospitalisation_anterieure ,
					$allaitement_mat_exclusif ,
					$preparation_nourrissons,
					$alimentation_mixte ,
					$diversification_alimentaire ,
					$vaccin_bcg ,
					$vaccin_polio ,
					$vaccin_dtper ,
					$vaccin_rougeole ,
					$vaccin_rr ,
					$vaccin_dt ,
					$vaccin_hepatite_b ,
					$vaccin_act_hib ,
					$vaccin_autre ,
					$date_consultation
		)
		{
					$this->code_natinal = $code_natinal;
					$this->code_attrib = $code_attrib ;
					$this->nom = $nom ;
					$this->prenom	= $prenom ; 
					$this->refere	 = $refere ;
					$this->scolarite = $scolarite ;
					$this->electrophorese = $electrophorese ;
					$this->poids_naissance = $poids_naissance ;
					$this->asthme_fam = $asthme_fam ;
					$this->cancer_fam = $cancer_fam ;
					$this->cardiopathie_fam = $cardiopathie_fam ;
					$this->diabete_fam = $diabete_fam ;
					$this->epilepsie_fam= $epilepsie_fam ; 
					$this->hta_fam = $hta_fam ;
					$this->turberculose_fam = $turberculose_fam ;
					$this->autres_1 = $autres_1 ;
					$this->allergies_pers = $allergies_pers ;
					$this->asthme_pers = $allergies_pers ;
					$this->cardiopathie_pers = $cardiopathie_pers ;
					$this->chirurgie_trauma = $cardiopathie_pers ;
					$this->diabete_pers = $diabete_pers ;
					$this->diphterie_pers = $diphterie_pers ;
					$this->epilepsie_pers = $epilepsie_pers ;
					$this->hemoglobinopathie = $hemoglobinopathie ;
					$this->hta_pers = $hta_pers ;
					$this->ist_pers = $ist_pers ;
					$this->malaria_moins_1_mois = $malaria_moins_1_mois ;
					$this->malaria_plus_1_mois = $malaria_plus_1_mois ;
					$this->malf_congenitales = $malf_congenitales ;
					$this->malnutrition_perte_poids = $malnutrition_perte_poids ;
					$this->premature = $premature;
					$this->raa = $raa ;
					$this->rougeole = $rougeole ;
					$this->tuberculose_pers = $tuberculose_pers ;
					$this->varicelle = $rougeole ;
					$this->autres_2= $autres_2 ;
					$this->medicaments_actuels = $medicaments_actuels ;
					$this->hospitalisation_anterieure = $hospitalisation_anterieure ;
					$this->allaitement_mat_exclusif = $allaitement_mat_exclusif ;
					$this->preparation_nourrissons= $preparation_nourrissons ;
					$this->alimentation_mixte = $alimentation_mixte ;
					$this->diversification_alimentaire = $diversification_alimentaire ;
					$this->vaccin_bcg = $vaccin_bcg ;
					$this->vaccin_polio = $vaccin_polio ;
					$this->vaccin_dtper = $vaccin_dtper ;
					$this->vaccin_rougeole = $vaccin_rougeole ;
					$this->vaccin_rr = $vaccin_rr ;
					$this->vaccin_dt = $vaccin_dt ;
					$this->vaccin_hepatite_b = $vaccin_hepatite_b ;
					$this->vaccin_act_hib = $vaccin_act_hib ;
					$this->vaccin_autre = $vaccin_autre ;
					$this->date_consultation= $date_consultation ;
		}

		public function getCode_natinal(){ return $this->code_natinal ; }
		public function getCode_attrib(){ return $this->code_attrib ;}
		public function getnom(){ return $this->nom ;}
		public function getPrenom(){ return $this->prenom ;}

		public function getRefere	 (){ return $this->refere ;}
		public function getScolarite (){ return $this->scolarite ;}
		public function getElectrophorese (){ return $this->electrophorese ;}

		public function getPoids_naissance(){ return $this->poids_naissance ;} 
		public function getAsthme_fam (){ return $this->asthme_fam ;}
		public function getCancer_fam (){ return $this->cancer_fam ;}

		public function getCardiopathie_fam (){ return $this->cardiopathie_fam ;}
		public function getDiabete_fam (){ return $this->diabete_fam ;}
		public function getEpilepsie_fam (){ return $this->epilepsie_fam;}

		public function getHta_fam (){ return $this->hta_fam ;}
		public function getTurberculose_fam (){ return $this->turberculose_fam;}
		public function getAutres_1 (){ return $this->autres_1 ;}

		public function getAllergies_pers (){ return $this->allergies_pers ;}
		public function getAsthme_pers (){ return $this->asthme_pers ;}
		public function getCardiopathie_pers (){ return $this->cardiopathie_pers ;}

		public function getChirurgie_trauma (){ return $this->chirurgie_trauma;}
		public function getDiabete_pers (){ return $this->diabete_pers ;}
		public function getDiphterie_pers (){ return $this->diphterie_pers ;}

		public function getEpilepsie_pers(){ return $this->epilepsie_pers ;} 
		public function getHemoglobinopathie (){ return $this->hemoglobinopathie ;}
		public function getHta_pers (){ return $this->hta_pers ;}

		public function getIst_pers (){ return $this->ist_pers ;}
		public function getMalaria_moins_1_mois (){ return $this->malaria_moins_1_mois ;}
		public function getMalaria_plus_1_mois (){ return $this->malaria_plus_1_mois ;}

		public function getMalf_congenitales (){ return $this->malf_congenitales ;}
		public function getMalnutrition_perte_poids (){ return $this->malnutrition_perte_poids ;}
		public function getPremature (){ return $this->premature ;}

		public function getRaa (){ return $this->raa ;}
		public function getRougeole (){ return $this->rougeole ;}
		public function getTuberculose_pers (){ return $this->tuberculose_pers ;}

		public function getVaricelle (){ return $this->varicelle ;}
		public function getAutres_2(){ return $this->autres_2 ;}
		public function getMedicaments_actuels (){ return $this->medicaments_actuels ;}

		public function getHospitalisation_anterieure (){ return $this->hospitalisation_anterieure ;}
		public function getAllaitement_mat_exclusif (){ return $this->allaitement_mat_exclusif ;}
		public function getPreparation_nourrissons(){ return $this->preparation_nourrissons;}

		public function getAlimentation_mixte (){ return $this->alimentation_mixte ;}
		public function getDiversification_alimentaire (){ return $this->diversification_alimentaire ;}
		public function getVaccin_bcg (){ return $this->vaccin_bcg ;}

		public function getVaccin_polio (){ return $this->vaccin_polio ;}
		public function getVaccin_dtper (){ return $this->vaccin_dtper ;}
		public function getVaccin_rougeole (){ return $this->vaccin_rougeole ;}

		public function getVaccin_rr (){ return $this->vaccin_rr ;}
		public function getVaccin_dt (){ return $this->vaccin_dt ;}
		public function getVaccin_hepatite_b (){ return $this->vaccin_hepatite_b ;}

		public function getVaccin_act_hib (){ return $this->vaccin_act_hib ;}
		public function getVaccin_autre (){ return $this->vaccin_autre ;}
		public function getDate_consultation(){ return $this->date_consultation ;}


	}
?>