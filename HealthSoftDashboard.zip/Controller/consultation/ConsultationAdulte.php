<?php

	/**
	* 
	*/
	class ConsultationAdulte
	{

							private $id_consultation;
							private $date_consultation ;
							private $code_national ;
							private $code_attrib ;
							private $nom ;
							private $prenom; 
							private $age ;
							private $sexe ;
							private $group_sanguin; 
							private $analyse ;
							private $depistage_ca_col; 
							private $depistage_ca_prostate; 
							private $asthme_fam ;
							private $cancer_fam ;
							private $cardiopathie_fam; 
							private $diabete_fam ;
							private $epilepsie_fam; 
							private $HTA_fam ;
							private $turbeculose_fam; 
							private $autres_1 ;
							private $accident_cere_vasc; 
							private $allergies ;
							private $asthme_pers; 
							private $cancer_pers ;
							private $cardiopathi ;
							private $chirurgie_trauma; 
							private $diabete_pers ;
							private $epilepsie_pers; 
							private $grossesse ;
							private $hemoglobinopathie ;
							private $hta_pers ;
							private $hypercholesteromie; 
							private $ist ;
							private $malnutrition; 
							private $malarie_moins_1_mois; 
							private $malaria_plus_1_mois ;
							private $tuberculose_pers ;
							private $trouble_psychyatriques; 
							private $alcool ;
							private $drogue ;
							private $tabac ;
							private $autres_2; 
							private $autres_3;
							private $medicaments_actuels;
							private $remarque;
							private $poids ;
							private $ta ;
							private $taille ;
							private $temp ;
							private $pouls ;
							private $fr ;
							private $imc ;
							private $nom_Prenom_prestataire;
		
		//
		function __construct(
							$id_consultation,
							$date_consultation, 
							$code_national, 
							$code_attrib, 
							$nom, 
							$prenom, 
							$age, 
							$sexe, 
							$group_sanguin, 
							$analyse, 
							$depistage_ca_col, 
							$depistage_ca_prostate,
							$asthme_fam, 
							$cancer_fam, 
							$cardiopathie_fam, 
							$diabete_fam, 
							$epilepsie_fam,
							$HTA_fam, 
							$turbeculose_fam, 
							$autres_1, 
							$accident_cere_vasc, 
							$allergies, 
							$asthme_pers, 
							$cancer_pers, 
							$cardiopathi, 
							$chirurgie_trauma, 
							$diabete_pers, 
							$epilepsie_pers, 
							$grossesse, 
							$hemoglobinopathie, 
							$hta_pers, 
							$hypercholesteromie, 
							$ist, 
							$malnutrition, 
							$malarie_moins_1_mois, 
							$malaria_plus_1_mois, 
							$tuberculose_pers, 
							$trouble_psychyatriques, 
							$alcool, 
							$drogue, 
							$tabac, 
							$autres_2, 
							$autres_3,
							$medicaments_actuels,
							$remarque,
							$poids, 
							$ta,
							$taille, 
							$temp, 
							$pouls, 
							$fr, 
							$imc,
							$nom_Prenom_prestataire
		)
		{


							
							$this->code_national = $code_national;
							$this->code_attrib = $code_attrib;
							$this->nom = $nom;
							$this->prenom = $prenom;
							$this->age = $age;
							$this->sexe = $sexe;
							$this->group_sanguin = $group_sanguin;
							$this->analyse = $analyse;
							$this->depistage_ca_col = $depistage_ca_col;
							$this->depistage_ca_prostate = $depistage_ca_prostate;
							$this->asthme_fam = $asthme_fam;
							$this->cancer_fam = $cancer_fam;
							$this->cardiopathie_fam = $cardiopathie_fam;
							$this->diabete_fam = $diabete_fam;
							$this->epilepsie_fam = $epilepsie_fam;
							$this->HTA_fam = $HTA_fam;
							$this->turbeculose_fam = $turbeculose_fam;
							$this->autres_1 = $autres_1;
							$this->accident_cere_vasc = $accident_cere_vasc;
							$this->allergies = $allergies;
							$this->asthme_pers = $asthme_pers
							$this->cancer_pers = $cancer_pers
							$this->cardiopathi = $cardiopathi
							$this->chirurgie_trauma = $chirurgie_trauma
							$this->diabete_pers = $diabete_pers;
							$this->epilepsie_pers = $epilepsie_pers;
							$this->grossesse = $grossesse;
							$this->hemoglobinopathie = $hemoglobinopathie;
							$this->hta_pers = $hta_pers;
							$this->hypercholesteromie = $hypercholesteromie;
							$this->ist = $ist;
							$this->malnutrition = $malnutrition;
							$this->malarie_moins_1_mois = $malarie_moins_1_mois;
							$this->malaria_plus_1_mois = $malaria_plus_1_mois;
							$this->tuberculose_pers = $tuberculose_pers;
							$this->trouble_psychyatriques = $trouble_psychyatriques;
							$this->alcool = $alcool;
							$this->drogue = $drogue;
							$this->tabac = $tabac;
							$this->autres_2 = $autres_2;
							$this->autres_3 = $autres_3;
							$this->medicaments_actuels = $medicaments_actuels;
							$this->remarque = $remarque;
							$this->poids = $poids;
							$this->ta = $ta;
							$this->taille = $taille;
							$this->temp = $temp;
							$this->pouls = $pouls;
							$this->fr = $fr;
							$this->imc = $imc;
							$this->nom_Prenom_prestataire = $nom_Prenom_prestataire;
			
		}

							function getId_consultation(){return $this->id_consultation;}
							function getDate_consultation(){return $this->date_consultation;} 
							function getCode_national(){return $this->code_national;} 

							function getCode_attrib(){return $this->code_attrib;} 
							function getNom(){return $this->nom;} 
							function getPrenom(){return $this->prenom;} 

							function getAge(){return $this->age;} 
							function getSexe(){return $this->sexe;} 
							function getGroup_sanguin(){return $this->group_sanguin;} 

							function getAnalyse(){return $this->analyse;} 
							function getDepistage_ca_col(){return $this->depistage_ca_col;} 
							function getDepistage_ca_prostate(){return $this->depistage_ca_prostate;}

							function getAsthme_fam(){return $this->asthme_fam;} 
							function getCancer_fam(){return $this->cancer_fam;} 
							function getCardiopathie_fam(){return $this->cardiopathie_fam;} 

							function getDiabete_fam(){return $this->diabete_fam;} 
							function getEpilepsie_fam(){return $this->epilepsie_fam;}
							function getHTA_fam(){return $this->HTA_fam;} 

							function getTurbeculose_fam(){return $this->turbeculose_fam;} 
							function getAutres_1(){return $this->autres_1;} 
							function getAccident_cere_vasc(){return $this->accident_cere_vasc;} 

							function getAllergies(){return $this->allergies;} 
							function getAsthme_pers(){return $this->asthme_pers;} 
							function getCancer_pers(){return $this->cancer_pers;} 

							function getCardiopathie(){return $this->cardiopathie;} 
							function getChirurgie_trauma(){return $this->chirurgie_trauma;} 
							function getDiabete_pers(){return $this->diabete_pers;} 

							function getEpilepsie_pers(){return $this->epilepsie_pers;} 
							function getGrossesse(){return $this->grossesse;} 
							function getHemoglobinopathie(){return $this->hemoglobinopathie;} 

							function getHta_pers(){return $this->hta_pers;} 
							function getHypercholesteromie(){return $this->hypercholesteromie;} 
							function getIst(){return $this->ist;} 

							function getMalnutrition(){return $this->malnutrition;} 
							function getMalarie_moins_1_mois(){return $this->malarie_moins_1_mois;} 
							function getMalaria_plus_1_mois(){return $this->malaria_plus_1_mois;} 

							function getTuberculose_pers(){return $this->tuberculose_pers;} 
							function getTrouble_psychyatriques(){return $this->trouble_psychyatriques;} 
							function getAlcool(){return $this->alcool;} 

							function getDrogue(){return $this->drogue;} 
							function getTabac(){return $this->tabac;} 
							function getAutres_2(){return $this->autres_2;}

							function getAutres_3(){return $this->autres_3;}
							function getMedicaments_actuels(){return $this->medicaments_actuels;}
							function getRemarque(){return $this->remarque;}

							function getPoids(){return $this->poids;} 
							function getTa(){return $this->ta;}
							function getTaille(){return $this->taille;} 

							function getTemp(){return $this->temp;} 
							function getPouls(){return $this->pouls;} 
							function getFr(){return $this->fr;} 

							function getImc(){return $this->;}
							function getNom_Prenom_prestataire(){return $this->nom_Prenom_prestataire;}



	}

?>