<?php

class Patient {
	private $_idPatient;
	private $_nomPatient;
	private $_prenomPatient;
	private $_codeNationalPatient;
	private $_codeAttribueParLeSite;
	private $_datePatient; 
	private $_sexePatient;
	private $_communePatient;
	private $_telephonePatient;
	private $_lieuNaissancePatient;
	private $_localitePatient;
	private $_dateDeNaissancePatient;
	private $_agePatient;
	private $_professionPatient;
	private $_prenomMerePatient;
	private $_statutMaritalPatient;
//  contact en cas d'urgence
    private $_nomPrenomUrgence;
    private $_adresseUrgence;
    private $_foneUrgence;
	
// Personne responsable pour discussion d'etat malade
   private $_nomResp1;
   private $_lienResp1;
   private $_adresseResp1;
   private $_foneResp1;
   
   private $_nomResp2;
   private $_lienResp2;
   private $_adresseResp2;
   private $_foneResp2;
   

	
// cas d'un enfant personne autorise
   private $_nomPrenomAutEnfant;
   private $_lienParenteEnfant;
   private $_adresseAutEnfant;
   private $_telephoneAutEnfant;
	
	
 //protected $message = false;
	
	public $message="xxx";
	


    

    public function __construct (array $donnees) {
		$this->mouiller($donnees);
		
	}
	
	public function mouiller(array $Tabdata){
		
		 foreach ($Tabdata as $key=>$value){
			 $method='set'.ucfirst($key); 
			 if(method_exists($this, $method)){
				 $this->$method($value);
			 }
		 }
	 }
    public function idPatient(){return $this->_idPatient;  } 
	public function nomPatient(){return $this->_nomPatient;}
	public function prenomPatient(){return $this->_prenomPatient;}
	public function codeNationalPatient(){return $this->_codeNationalPatient;}
	public function codeAttribueParLeSite(){return $this->_codeAttribueParLeSite;}
	public function sexePatient(){return $this->_sexePatient;}
	public function communePatient(){return $this->_communePatient;}
	public function telephonePatient(){return $this->_telephonePatient;}
	public function lieuNaissancePatient(){return $this->_lieuNaissancePatient;}
	public function localitePatient(){return $this->_localitePatient;}
	public function dateDeNaissancePatient(){return $this->_dateDeNaissancePatient;}
	public function agePatient(){return $this->_agePatient;}
	public function professionPatient(){return $this->_professionPatient;}
	public function prenomMerePatient(){return $this->_prenomMerePatient;}
	public function statutMaritalPatient(){return $this->_statutMaritalPatient;}
	//public function datePatient(){return  $this->datePatient;}
	// urgence 
	public function nomPrenomUrgence(){return $this->_nomPrenomUrgence;}
	public function adresseUrgence() {return $this->_adresseUrgence;}
	public function foneUrgence(){return $this->_foneUrgence;}
	
	// Responsable pour discussion etat malade
	
	public function nomResp1(){return $this->_nomResp1;}
	public function lienResp1(){return $this->_lienResp1;}
	public function adresseResp1(){return $this->_adresseResp1;}
	public function foneResp1(){return $this->_foneResp1;}
	
	public function nomResp2(){return $this->_nomResp2;}
	public function lienResp2(){return $this->_lienResp2;}
	public function adresseResp2(){return $this->_adresseResp2;}
	public function foneResp2(){return $this->_foneResp2;}
	
	// personne autorisee pour lenfant 
	
	public function nomPrenomAutEnfant(){return $this->_nomPrenomAutEnfant;}
	public function lienParenteEnfant(){return $this->_lienParenteEnfant;}
	public function adresseAutEnfant(){return $this->_adresseAutEnfant;} 
	public function telephoneAutEnfant(){return $this->_telephoneAutEnfant;}
	
	
	public function setIdPatient($idPatient)
  {$this->_idPatient = $idPatient;
    //$idPatient = (int) $idPatient;
    
    //if ($idPatient > 0)
    //{
      
    //}
  }
	
	

	public function setNomPatient($nomPatient) {
		if (is_string($nomPatient) && !empty($nomPatient)){ 
		$this->_nomPatient=$nomPatient;

	}
		
	else {
			
			$message="champ nom vide";
			
		}
	}
	
	public function setPrenomPatient ($prenomPatient){
		if (is_string($prenomPatient) && !empty($prenomPatient)){
		$this->_prenomPatient=$prenomPatient;
	     } else{
			
		   
		   
			
		}
	}
	
	public function setCodeNationalPatient($codeNationalPatient){
		if(!is_int($codeNationalPatient) && !empty($codeNationalPatient))
		{
			$this->_codeNationalPatient=$codeNationalPatient;
		}
	    
	    else{

	    	
	    }
	}
		
	public function setcodeAttribueParLeSite($codeAttribueParLeSite){
		if (!empty($codeAttribueParLeSite)) {
		 $this->_codeAttribueParLeSite=$codeAttribueParLeSite;
		} else{

	    	
	    }
	}
   
    
    public function setSexePatient($sexePatient){
    	if(is_string($sexePatient) && !empty($sexePatient)) {
    		$this->_sexePatient=$sexePatient;
    	} else{

	    	//echo "Champ vide ou Int non fourni";
	    }
		
	}
	

	public function setcommunePatient($communePatient){
		if(is_string($communePatient) && !empty($communePatient))
		{
			$this->_communePatient=$communePatient;

		}else{

	    	//echo "Champ vide ou Int non fourni";
	    }
	}
	

	public function setTelephonePatient($_telephonePatient)
	{   
		if (is_string($_telephonePatient) && !empty($_telephonePatient)){
	    $this->_telephonePatient = $_telephonePatient;
	    } else{

	    	//echo "Champ vide ou Int non fourni";
	    }
	}
	
	public function setLieuNaissancePatient($_lieuNaissancePatient)
	{
	    if(is_string($_lieuNaissancePatient) && !empty($_lieuNaissancePatient)){
	    $this->_lieuNaissancePatient = $_lieuNaissancePatient;
	}
	else {

	}
	}
	
	
	public function setLocalitePatient($_localitePatient)
	{
		if(is_string($_localitePatient) && !empty($_localitePatient)){
	    $this->_localitePatient = $_localitePatient;
	}
	else{

	}
	}
	
	
	public function setDateDeNaissancePatient($_dateDeNaissancePatient)
	{ 
	    $this->_dateDeNaissancePatient = $_dateDeNaissancePatient;
	}
	
	
	public function setAgePatient($_agePatient){
		if(!is_int($_agePatient)&& !empty($_agePatient)){
	    $this->_agePatient = $_agePatient;
	     }
	     else {

	     }
	}
	
	
	public function setProfessionPatient($_professionPatient)	{
		if (is_string($_professionPatient) && !empty($_professionPatient)) {
			
			$this->_professionPatient = $_professionPatient;
	} else{

	     }

	}
	
	
	
	
	public function setPrenomMerePatient($_prenomMerePatient){
	    if (is_string($_prenomMerePatient) && !empty($_prenomMerePatient)){	
	    $this->_prenomMerePatient = $_prenomMerePatient;
	}   else{


	        }
	}
	
	
	public function setStatutMaritalPatient($_statutMaritalPatient)
	{   if (is_string($_statutMaritalPatient) && !empty($_statutMaritalPatient)){
	    $this->_statutMaritalPatient = $_statutMaritalPatient;
	     } else{

	     }
	}
	
	
	public function setNomPrenomUrgence($_nomPrenomUrgence)
	{
		if(is_string($_nomPrenomUrgence) && !empty($_nomPrenomUrgence)){
	    $this->_nomPrenomUrgence = $_nomPrenomUrgence;
	    } else{

	    }
	}
	
	
	public function setAdresseUrgence($_adresseUrgence){   
		if(is_string($_adresseUrgence) && !empty($_adresseUrgence)){
	    $this->_adresseUrgence = $_adresseUrgence;
	       } 
	    else {

	          }
	}
	
	public function setFoneUrgence($_foneUrgence)
	{
		if(is_string($_foneUrgence) && !empty($_foneUrgence)){
	    $this->_foneUrgence = $_foneUrgence;
	} else {

	    }

	}
	
	
	public function setNomResp1($_nomResp1)
	{
	    $this->_nomResp1 = $_nomResp1;
	}
	
	public function setLienResp1($_lienResp1)
	{
	    $this->_lienResp1 = $_lienResp1;
	}
	
	
	public function setAdresseResp1($_adresseResp1)
	{
	    $this->_adresseResp1 = $_adresseResp1;
	}
	
	
	public function setFoneResp1($_foneResp1)
	{
	    $this->_foneResp1 = $_foneResp1;
	}
	
	
	public function setNomResp2($_nomResp2)
	{
	    $this->_nomResp2 = $_nomResp2;
	}
	

	public function setLienResp2($_lienResp2)
	{
	    $this->_lienResp2 = $_lienResp2;
	}
	
	public function setAdresseResp2($_adresseResp2)
	{
	    $this->_adresseResp2 = $_adresseResp2;
	}
	
	public function setFoneResp2($_foneResp2)
	{
	    $this->_foneResp2 = $_foneResp2;
	}
	
	public function setNomPrenomAutEnfant($_nomPrenomAutEnfant)
	{
	    $this->_nomPrenomAutEnfant = $_nomPrenomAutEnfant;
	}
	
	public function setLienParenteEnfant($_lienParenteEnfant)
	{
	    $this->_lienParenteEnfant = $_lienParenteEnfant;
	}
	
	
	public function setAdresseAutEnfant($_adresseAutEnfant)
	{
	    $this->_adresseAutEnfant = $_adresseAutEnfant;
	}
	
	public function setTelephoneAutEnfant($_telephoneAutEnfant)
	{
	    $this->_telephoneAutEnfant = $_telephoneAutEnfant;
	}

    public function AgePatientCalculate($dateDeNaissancePatient){
     
	$dateDeNaissancePatient='"'.$dateDeNaissancePatient.'"';
     
    //$today = new DateTime();
    $birthdate = new DateTime($dateDeNaissancePatient);
    $interval = $today->diff($birthdate);
    echo $interval->format('%y years');
	}
	
}	
	
	
	
	
	
	


?>