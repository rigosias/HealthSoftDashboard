<?php 

		session_start(); 

		//session_destroy();

		//include "global.php"; 

		include("../include/connexion.php");
		$bool = false;
		
		if(isset($_POST['username']) && isset($_POST['password'])){
   
            $sql= "SELECT password,username FROM users WHERE username='".$_POST['username']."';";

			$sql_2 = "";
            $result_1 = $pdo->prepare( $sql );
			$result_1->execute();
			

			for($i=0; $row = $result_1->fetch(PDO::FETCH_OBJ); $i++){
				$sql3 = password_verify($_POST['password'], $row->password);
				 $sql_2 = $row->password;
			
				
			} 
			

			if($sql3){
				
			
				$sql= "SELECT id,nom,prenom,username,password,status,id_perm FROM users WHERE username='".$_POST['username']."' and password='".$sql_2."';"; 
									
				$result = $pdo->prepare( $sql );
				$result->execute();

				//$result->fetch(PDO::FETCH_OBJ);

				//$row = $result->fetch(PDO::FETCH_OBJ);
       
			    for($i=0; $row = $result->fetch(PDO::FETCH_OBJ); $i++){
					
					$id= $row->id; 
					$nom= $row->nom; 
					$prenom= $row->prenom; 

					$username= $row->username; 				
					$status= $row->status; 

					 $id_perm= $row->id_perm; 	

					//====================

					$_SESSION['id'] =$id ;
					$_SESSION['nom'] =$nom ; 
					$_SESSION['prenom'] =$prenom ;

					$_SESSION['username'] =$username ;
					$_SESSION['status'] =$status ; 				

					$_SESSION['id_perm'] =$id_perm;	
                    $bool = true;
                     $_SESSION['sessionAccess'] ="Oui" ;  
				
               }

                header("location:../home/Dashboard.php"); 

			}else {
				$_SESSION['sessionAccess'] ="Non" ; 
				echo "Your details did not match"; 
                 header("location:../index.php");
                 exit;
                

			}	

					

				

			

		}

			//if($bool){

			//}
			
		//else{ 

				// 
				//exit; 
		   //} 

	
				// 
				//exit;  
				//}

?>