<?php 

	session_start();

	// variable declaration
	$username = "";
	$email    = "";
	$errors = array(); 
	$_SESSION['success'] = "";

	

	// connect to database
	$db = mysqli_connect('localhost', 'root', '', 'genius');

	
	if (isset($_POST['login_user'])) {

		$username = mysqli_real_escape_string($db, $_POST['username']);
		$password = mysqli_real_escape_string($db, $_POST['password']);

		if (empty($username)) {
			array_push($errors, "Username is required");
		}

		if (empty($password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {

			//$password = md5($password);

			$query = "SELECT * FROM users WHERE username='$username';";

			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) {

				

				while ($row = mysqli_fetch_assoc($results))
				{	

					$sql3 = password_verify( $password, $row['password']);


					$userid = $row['userid'];
					$username = $row['username'];
					$id_perm = $row['id_perm'];	

					$query = "SELECT nom,description,status FROM permissions WHERE id_perm='$id_perm';";
					$results = mysqli_query($db, $query);

					$hopital = "";

					while ($row_2 = mysqli_fetch_assoc($results))
					{  
						$hopital =  $row_2['nom'];						
					}

					$_SESSION['HOPITAL_NAME'] = $hopital;

				    $item_array = array(  
	                     'userid' => $userid,  
	                     'username' => $username,
	                     'hopital' => $hopital            
	                ); 

				    $_SESSION['FOR_SEACH'] = $userid;

	                $_SESSION["hopitalUserSession"][0] = $item_array;

	                $query = "INSERT INTO login_history(username,userid,date_in) VALUES('$username',$userid,now());";

					$resul = mysqli_query($db, $query);


				    // $_SESSION['country'] = $row['country'];
				    // $_SESSION['state'] = $row['state'];
				    // $_SESSION['city'] = $row['city'];
				    // $_SESSION['adress'] = $row['adress'];
				    // $_SESSION['email'] = $row['email'];

				    //  `userid` Int( 255 ) AUTO_INCREMENT NOT NULL,
					// `nom` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `prenom` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `cin` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `adresse` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `tel` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `username` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `password` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `status` VarChar( 255 ) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
					// `date` Date NOT NULL,
					// `id_perm`

				    $_SESSION['username'] = $row["username"];
					$_SESSION['aproved'] = "Yes";

					if($sql3){
						header('location: home/');
					}
					

				}
				
				

			}else {
				array_push($errors, "Wrong username/password combination");
			}
		}
	}

?>